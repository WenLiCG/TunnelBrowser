# 71b 修复报告

仅修改工作目录中的 `71-tb4-config.ps1`，保留 UTF-8 BOM；本报告按 PROMPT-71b.md 要求写入 /tmp。未访问网络、未连接 Windows、未修改其它任务文件。

## 对照要求 1–4

1. wevtutil 调用前清空 `$global:LASTEXITCODE`，调用后读取同一全局变量，避免函数局部变量遮蔽真实退出码。auditpol 直接读取 Process.ExitCode；未启动时记录 NOT_STARTED。
2. auditpol 的所有调用统一使用 System.Diagnostics.Process/ProcessStartInfo，UseShellExecute=False，Arguments 为显式完整字符串，不经过 PowerShell 原生命令参数封送。GUID 保留花括号且不用本地化名称。记录 Program、实际 Arguments、完整 stdout/stderr、退出码及调用异常。异步读取两个输出管道避免阻塞。所有变更之前增加 `/list /subcategory:* /v`，完整结果进入同一个本地文件，stdout 仅报告诊断退出码与所需错误分类，不输出列表内容。
3. WindowsPrincipal 只读判定管理员状态，写本地记录和 stdout。每次 auditpol/wevtutil 调用均按输出中的 0x00000522、0x00000005、0x00000057 分类；否则成功为 OK，其余为 OTHER。数值退出码及分类同时写本地和摘要。
4. 变更前审核查询为 INVALID_PARAMETER 时跳过审核设置，记录明确原因；日志大小仍独立处理。配置失败且拷贝成功最终 exit 1，拷贝失败优先 exit 2；均成功 exit 0。保留变更前后原始输出、本地记录优先、共享单文件拷贝及最多六次尝试逻辑，成功拷贝后不再改本地记录。

## PowerShell 5.1 兼容性

静态检查未发现原脚本使用 5.1 不支持的语法，无此类语法需要修正。保留的 Select-Object -SkipLast 在 5.1 可用。新增调用使用 Windows PowerShell 5.1 / .NET Framework 支持的 ProcessStartInfo、ReadToEndAsync、WindowsPrincipal；没有三元运算符或空合并运算符。

## 静态检查命令与结果

在工作目录执行：

```sh
grep -Ein 'Set-ItemProperty|Set-Service|Set-ScheduledTask|Stop-Process|Stop-Service|Stop-Computer|Restart-Service|Restart-Computer|Remove-Item|Clear-EventLog|Clear-WinEvent|wevtutil cl|logoff|tsdiscon|rwinsta|shutdown|taskkill|reg add|reg delete|sc\.exe|netsh' 71-tb4-config.ps1
grep -Ein '/success|/r|/rt|/ab|/retention|/autobackup|cl ' 71-tb4-config.ps1
command -v pwsh
```

两个 grep 均无输出、退出码 1，即匹配 0 次。pwsh 未找到，未执行语法解析。

另用 Python 结构断言确认：Copy-Item 调用位置仅一处；只读诊断在审核设置之前；读取全局 LASTEXITCODE；不再存在旧局部清空写法；无 `??`；UTF-8 BOM 存在。全部通过。

## 未验证项

未在 Windows 实际运行；未验证 Windows PowerShell 5.1 解析、auditpol GUID 参数实际接受情况、当地控制台输出解码、实际权限分类、设置及回读结果、共享盘拷贝和重试。以上静态检查不替代 Windows 运行验证。
