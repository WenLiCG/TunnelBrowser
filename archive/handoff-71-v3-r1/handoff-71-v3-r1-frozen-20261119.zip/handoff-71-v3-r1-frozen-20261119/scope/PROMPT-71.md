# TB-4：写配置脚本 71-tb4-config.ps1（Codex gpt-6.1-sol）

你在共享电脑的独立工作目录 `/workspace/codex/tunnelbrowser/TB-4-investigate/` 中工作。本目录不是 git 仓库。只在这个目录里创建或修改文件，不要访问网络，不要读取本目录以外的仓库、脚本或日志，不要索取或写入密码、密钥、主机名或主机 IP，不要使用 `--dangerously-bypass-approvals-and-sandbox`，不要改用其他模型或配置。

本机是 Linux，不能在 Windows 上执行该脚本，也不要尝试连接任何 Windows 主机。不要修改已有的 `70-tb4-collect.ps1`、`SCRIPT-NOTES.md`、`TASK.md` 或本提示文件。

## 唯一交付

写出 `71-tb4-config.ps1`（放在本目录根下），面向 Windows PowerShell 5.1，将由已有 runner（`powershell.exe -NoProfile -ExecutionPolicy Bypass -File`）执行。脚本结束必须用与 `70-tb4-collect.ps1` 相同的退出码约定：

- 两项配置都成功，且把本地记录文件一次拷到共享盘成功：`exit 0`
- 配置已做（或已完整记录失败原因），但共享盘拷贝最终失败：`exit 2`
- 脚本级未处理异常：`exit 1`

stdout 只输出短摘要（开始/结束时间、前后关键值、命令退出码、本地路径、拷贝是否成功、EXIT 意图）。runner 会把 stdout 收到共享盘 `out/`，必须很小。详细内容只写本地文件。

## 目标（范围恰好两项，PM 已批准，此外什么都不要改）

在 Windows 测试机上做且仅做：

(a) 打开 Logon 子类的**失败**审核，使事件 4625 会被记录。必须用 GUID，避免区域语言名称问题：

```
auditpol.exe /set /subcategory:{0CCE9215-69AE-11D9-BED3-505400000000} /failure:enable
```

**不要**传 `/success:...`。成功审核保持系统当前原值，不得开启或关闭成功审核。

(b) 把 Security 日志最大尺寸设为**至少** 256MB，即至少 `268435456` 字节：

```
wevtutil.exe sl Security /ms:<BYTES>
```

规则：

- 先读取当前最大尺寸。若当前值已经 `>= 268435456`，不要缩小，保持原值，并在记录里写明「已满足、未改」。
- 若当前值小于 256MB，则设为 `268435456`。
- **禁止清空日志**：不要 `wevtutil cl`、不要 `Clear-EventLog`、不要 `Clear-WinEvent`，也不要给 `wevtutil sl` 加会清日志的开关。
- **不要改保留策略（retention）或溢出动作**，不要传 `/r`、`/rt`、`/ab`、`/retention`、`/autobackup` 等参数，以免改成会删除数据的模式。只允许改最大尺寸 `/ms`。

## 记录与拷贝（必须）

1. 先确保目录 `C:\qa\tb4` 存在（`New-Item -ItemType Directory -Force`，可以）。
2. 在做任何变更**之前**，把下列「变更前」原始输出写入本地文件 `C:\qa\tb4\71-config.txt`（UTF-8）：
   - 时间戳（ISO，含时区偏移）
   - `auditpol.exe /get /subcategory:{0CCE9215-69AE-11D9-BED3-505400000000}` 的完整输出和退出码
   - `wevtutil.exe gl Security` 的完整输出和退出码（其中应能看到 maxSize、retention 等）
3. 再执行上述两项变更，记录每条命令的完整输出和退出码。
4. 变更**之后**再跑一遍同样的 `auditpol /get` 和 `wevtutil gl Security`，把「变更后」完整输出和退出码追加到同一文件。
5. 若某条命令失败，把错误和退出码写入该文件，不要继续盲目改其他不在范围内的东西；能安全完成的另一项仍应尝试，并在摘要里写清哪一项成功/失败。
6. **详细结果先全部写在本地** `C:\qa\tb4\71-config.txt`。禁止在循环里对 `\\tsclient\tb` 做 `Add-Content` / `Set-Content` / `Out-File`。
7. 全部完成后，**一次**把该文件拷到共享盘：
   - 先 `New-Item -ItemType Directory -Force` 保证 `\\tsclient\tb\tb4\raw` 存在
   - 然后 `Copy-Item` 把 `C:\qa\tb4\71-config.txt` **一次**拷到 `\\tsclient\tb\tb4\raw\`
   - 只拷这一个文件，不要递归拷整个 `C:\qa\tb4`（那里可能有其他采集目录）
   - 若共享盘暂时不可见，最多重试 6 次、每次间隔 5 秒（用线程等待，不要引入额外外部命令）；仍失败则在 stdout 写清本地已完成、共享拷贝失败，然后 `exit 2`
8. 不要在拷贝成功后再改本地文件并二次拷贝。若需要记录拷贝结果，把最终 `ShareCopy` / `EXIT` 写到 stdout 即可，或在拷贝前就把可确定的内容写完。

## 硬性禁止（脚本中不得作为命令出现，注释里也不要写完整可执行调用）

禁止改防火墙、RDP 端口、服务、用户账户，禁止重启、注销、断开会话、结束他人或系统进程。禁止出现：

`Set-ItemProperty`、`Set-Service`、`Set-ScheduledTask`、`Stop-Process`、`Stop-Service`、`Stop-Computer`、`Restart-Service`、`Restart-Computer`、`Remove-Item`、`Clear-EventLog`、`Clear-WinEvent`、`wevtutil cl`、`logoff`、`tsdiscon`、`rwinsta`、`shutdown`、`taskkill`、`reg add`、`reg delete`、`sc.exe`、`netsh`、`netsh.exe`

除上述两项批准的变更外，不要改注册表、不要改其他审核子类、不要改其他日志的大小或保留策略。不要访问网络。不要在脚本里写任何密码、主机名或主机 IP。

`$ErrorActionPreference` 不要用会让你丢掉命令退出码的方式；对 `auditpol` / `wevtutil` 请检查 `$LASTEXITCODE`。

## 完成

只交付 `71-tb4-config.ps1`（UTF-8）。不要创建其他无关大文件。不要修改 70 脚本。完成后停止。未能在 Windows 上实际运行，在脚本注释里用一两行简体中文说明这一点即可，不要另写长文档。
