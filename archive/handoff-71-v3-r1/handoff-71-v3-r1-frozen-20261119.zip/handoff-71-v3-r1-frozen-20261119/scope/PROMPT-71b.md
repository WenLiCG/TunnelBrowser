# TB-4：修复配置脚本 71-tb4-config.ps1（第 2 版，Codex gpt-6.1-sol）

工作目录 `/workspace/codex/tunnelbrowser/TB-4-investigate/`（非 git 仓库）。只改 `71-tb4-config.ps1`，其余文件（含 `71-tb4-config.v1.ps1` 备份、70 脚本、PROMPT-71.md、TASK.md、SCRIPT-NOTES.md、本文件）不得修改。不访问网络，不连任何 Windows 主机，不写密码/主机名/IP，不用 `--dangerously-bypass-approvals-and-sandbox`。

原需求、范围、退出码约定、记录与一次性拷贝、硬性禁止清单全部以 `PROMPT-71.md` 为准，继续有效（只改 Logon 失败审核 + Security 日志 maxSize ≥ 268435456；不碰 success 审核、retention、autobackup；禁止清日志等）。

## 第 1 版在 Windows 上的实际结果（证据摘要）

- `auditpol.exe /get /subcategory:{0CCE9215-69AE-11D9-BED3-505400000000}` 打印用法并报「发生错误 0x00000057: 参数错误」——命令没被 auditpol 识别，不是权限问题（同机未提权跑 `auditpol` 其他命令时报的是 0x00000522「缺少特权」）。
- 所有命令记录为 `Exit=NOT_STARTED`，包括正常输出 `maxSize: 20971520` 的 `wevtutil gl Security`，导致 maxSize 被判读不到、大小项被跳过。

## 必须修的两处

1. **退出码**：`Invoke-Recorded` 里 `$LASTEXITCODE = $null` 在函数作用域创建了局部变量，遮蔽了原生命令写入的全局值。改为读取 `$global:LASTEXITCODE`（调用前可把 `$global:LASTEXITCODE` 置为一个哨兵值以识别「没启动」）。确保原生命令真正的退出码被记录。
2. **auditpol 传参**：换一种不会被误解析的方式传 `/subcategory:{GUID}`。要求：
   - 选择在 Windows PowerShell 5.1 下对含花括号的参数最稳妥的方式（例如经 `cmd.exe /d /c` 传一整条命令行、或用 `System.Diagnostics.Process`/`ProcessStartInfo` 显式给出 Arguments 字符串并读取 ExitCode 与 stdout/stderr），在注释里用一两句简体中文说明为何这样做。
   - 记录里写出实际传给进程的完整参数字符串。
   - 仍只用 GUID，不用本地化名称。
   - 在任何变更之前，额外做一次只读诊断：`auditpol.exe /list /subcategory:* /v` 用同样的调用方式执行，完整输出写本地文件（用于确认 GUID 与传参方式），stdout 只写退出码。
3. **区分权限不足与参数错误**：对每条 auditpol/wevtutil 命令，除数值退出码外，再根据输出中的 `0x00000522` / `0x00000005`（拒绝访问）和 `0x00000057` 分类为 `INSUFFICIENT_PRIVILEGE` / `ACCESS_DENIED` / `INVALID_PARAMETER` / `OK` / `OTHER`，写入本地记录和 stdout 摘要。脚本开头再记录当前进程是否以管理员运行（用 `[Security.Principal.WindowsPrincipal]` 判定，只读，不尝试提权），写进记录和 stdout。
4. 如果「变更前」的 auditpol /get 被分类为 INVALID_PARAMETER，就不要再执行 `/set`（避免盲改），在记录与摘要里写清，并按失败处理（最终 exit 1，但仍完成本地记录和一次拷贝；拷贝失败则 exit 2）。maxSize 一项照常独立进行。

## 其它

- 保持 PowerShell 5.1 兼容；不要用 PS 7 才有的语法（如 `-SkipLast` 在 5.1 的 `Select-Object` 上存在，可以；三元运算符 `?:`、`??` 不行）。检查原脚本里是否有 5.1 不支持的写法并一并修正，在报告里列出。
- 在 Linux 上做静态检查：确认禁止清单里的命令/字符串在新脚本中 0 次出现（用 grep 给出结果），确认没有 `/success`、`/r`、`/rt`、`/ab`、`cl `。如本机有 `pwsh` 可做语法解析检查，没有就写明未做。
- 脚本顶部注释一两行简体中文：未在 Windows 实际运行；第 2 版修复了什么。

## 报告

写到 `/tmp/71b-codex-report.md`：改动要点（对照上面 1–4 条）、选择的 auditpol 调用方式与理由、静态检查命令与结果、未验证项。完成后停止。
