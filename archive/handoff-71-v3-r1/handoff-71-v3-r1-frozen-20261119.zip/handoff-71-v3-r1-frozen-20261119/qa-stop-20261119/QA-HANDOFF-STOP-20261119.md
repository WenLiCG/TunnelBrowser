# TunnelBrowser QA 停止开发交接

日期：2026-11-19，America/Los_Angeles（PST）。依据用户11:20 PST要求：停止开发，完成handoff后更新GitHub。本文件只交接既有质量证据，不启动修复、复测、Windows通道、配置写入或发布。

## 接手与版本
接手人：PM汇总，由既有项目唯一更新负责人归档到GitHub；QA不改作者分支，不另开重叠更新。
任务：脚本71 v3-r1，第二轮独立QA结束并冻结。
候选：`tbshare/tb4/jobs/71-tb4-config.v3-r1.ps1`，sha256 `57ed8d2beb604b0c061e0346303ba252947bea3b94ead89ff3a98372945d55cc`。
本次未实时核对仓库URL、PR、base/head及工作分支，均由更新负责人从既有项目记录核实，不以旧main或Release猜测。原作者生成方式与自测详见开发handoff；作者41/41不属于独立QA结论。

## 已有独立结果
总体fail，质量建议no-go；Windows执行blocked/未授权。共享Linux、PowerShell7.5.13，用原候选进程与auditpol/wevtutil离线桩。既有20例20通过；独立新增边界6例4通过2失败。原v3首轮及r1第二轮日志均保留，未因重试覆盖首次失败。
两项高严重度缺陷：
1. 行158–160及256：GUID匹配无首尾约束。list CSV官方GUID后附FFFF仍被接受，离线桩记录/set与sl各1次、exit0；预期拒绝且零写。
2. 行184–200：get CSV名称Logon而GUID为Logoff被OR逻辑接受，离线桩记录/set与sl各1次、exit0；预期名称与GUID冲突时零写。
通过边界：原值冲突、list同GUID不同名称、未知本地化、CSV缺失setting均零写。

## 复现与证据
不在本次交接运行以下命令；只是保留原复现方法：
`PATH=/home/box/opt/powershell/7:$PATH /home/box/opt/powershell/7/pwsh -NoProfile -File /workspace/tunnelbrowser/qa-71-v3-r1-57ed8d2b/Run-Boundaries.ps1 -ScriptUnderTest /workspace/tunnelbrowser/tbshare/tb4/jobs/71-tb4-config.v3-r1.ps1 -EvidenceFile /workspace/tunnelbrowser/qa-71-v3-r1-57ed8d2b/boundaries`
首轮目录：`/workspace/tunnelbrowser/qa-71-v3-0b28973d/`。
第二轮目录：`/workspace/tunnelbrowser/qa-71-v3-r1-57ed8d2b/`。
实际历史执行时间以原日志为准；本次不新增测试时间或结果。

## 未测、风险与授权
Windows PowerShell5.1、目标机器GUID映射/实际原值、真实写入与回退、恢复通道均未执行；Release未获本轮发布授权。离线桩缺陷不等于已在Windows造成写入。
原QA报告第20行“无生产影响已被证明”措辞不成立，正确边界为：仅离线模拟、未接触Windows，不能据此证明生产无风险。保留原报告作为历史证据，以本交接澄清，不回写历史结果。
用户本次授权是停止开发并将handoff更新到GitHub，不是批准第三轮修复、合并或发布。任何恢复开发/上机/发布均需另有授权。

## GitHub归档要求
将本交接、两轮原始证据与相应候选纳入既有项目记录，保留fail/no-go，不称质量已通过；核对敏感内容与文件清单后由唯一负责人更新。不能只留下共享电脑临时绝对路径；应提供仓库可访问的归档路径、提交SHA/链接及待办说明。QA本次没有执行GitHub更新，不宣称已推送。
建议后续获恢复授权时遵守software-handoff v1.3与software-release-gate v1.0；重验绑定实际候选，不能沿用作者自测。

## 本次核对的证据SHA256
- `QA-71-v3-r1-REVIEW.md`：`34f4dc7a0dfba3a3f303f550b038b78e86dfae198b63c64a64594070e9ef00ba`
- `Run-Boundaries.ps1`：`320f8f902488bc11a1bfdc53493d36d26d173408ed9b8b29b649e377b3607f84`
- `boundaries.log`：`05e948b867286c38591272091fa1616f813b44445ed7466ee2e470a60a94ae5a`
- `boundaries.json`：`5cc04e58fdf9e789d10fc680b7971367240fb58fde2c5d5a3f9525a5c17e8715`
- `boundaries.exit`：`4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`
- `run.log`：`1c421725836e6080fa69d3db138d1db44a83fb1c5e5c8ddd0e020712e97b5b08`
- `run.exit`：`9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
