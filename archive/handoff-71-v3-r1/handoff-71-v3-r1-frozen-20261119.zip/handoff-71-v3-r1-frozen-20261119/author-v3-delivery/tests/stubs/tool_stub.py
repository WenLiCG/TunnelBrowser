#!/usr/bin/env python3
"""Fake auditpol.exe / wevtutil.exe for isolated PowerShell tests. Logs argv; does not implement 71 script logic."""
import json
import os
import sys
from pathlib import Path

def main() -> int:
    journal = Path(os.environ["TB71_JOURNAL"])
    scenario_path = Path(os.environ["TB71_SCENARIO"])
    name = os.environ.get("TB71_STUB_PROGRAM") or Path(sys.argv[0]).name
    name = name.lower()
    args = sys.argv[1:]
    rec = {"program": name, "args": args}
    journal.parent.mkdir(parents=True, exist_ok=True)
    with journal.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")

    scenario = json.loads(scenario_path.read_text(encoding="utf-8"))
    kind = classify(name, args)
    if scenario.get("missing", {}).get(kind):
        # Simulate start failure by disappearing after log? The test harness
        # should omit the executable instead. If we got here, treat as fail.
        sys.stderr.write("stub reached unexpectedly for missing command\n")
        return 127
    action = scenario.get(kind) or {}
    stdout = action.get("stdout", "")
    stderr = action.get("stderr", "")
    state_path = Path(os.environ["TB71_JOURNAL"]).with_name("stub-state.json")

    if kind == "gl" and state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        new_size = state.get("maxSize")
        if new_size and stdout:
            import re
            stdout, n = re.subn(r"(?im)^(\s*maxSize\s*:\s*)([0-9]+)(\s*)$", r"\g<1>" + str(new_size) + r"\g<3>", stdout)
            if n == 0:
                stdout = stdout.rstrip() + "\n  maxSize: %s\n" % new_size

    if stdout:
        sys.stdout.write(stdout if stdout.endswith("\n") else stdout + "\n")
    if stderr:
        sys.stderr.write(stderr if stderr.endswith("\n") else stderr + "\n")
    code = int(action.get("exit", 0))
    if kind == "sl" and code == 0:
        ms = None
        for a in args:
            if a.startswith("/ms:"):
                ms = a.split(":", 1)[1]
        if ms:
            state_path.write_text(json.dumps({"maxSize": ms}), encoding="utf-8")
    return code

def classify(name: str, args: list) -> str:
    joined = " ".join(args)
    if name.startswith("auditpol"):
        if args and args[0] == "/list":
            return "list"
        if args and args[0] == "/get":
            return "get"
        if args and args[0] == "/set":
            return "set"
        return "auditpol_other"
    if name.startswith("wevtutil"):
        if args and args[0] == "gl":
            return "gl"
        if args and args[0] == "sl":
            return "sl"
        return "wevtutil_other"
    return "other"

if __name__ == "__main__":
    raise SystemExit(main())
