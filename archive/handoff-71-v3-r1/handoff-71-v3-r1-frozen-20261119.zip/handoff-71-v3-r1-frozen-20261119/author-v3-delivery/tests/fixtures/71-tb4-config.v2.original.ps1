﻿# 面向 Windows PowerShell 5.1；本脚本仅在 Linux 上静态检查，未在 Windows 实际运行。
# 第 2 版修复退出码作用域及 auditpol 参数传递，增加诊断和错误分类。
$ErrorActionPreference = 'Stop'
$started = Get-Date
$localRoot = 'C:\qa\tb4'
$localFile = Join-Path $localRoot '71-config.txt'
$share = '\\tsclient\tb\tb4\raw'
$subcategory = '/subcategory:{0CCE9215-69AE-11D9-BED3-505400000000}'
$minimum = [uint64]268435456

function Write-Detail([string]$Text) {
    Add-Content -LiteralPath $localFile -Value $Text -Encoding UTF8 -ErrorAction Stop
}

function Invoke-Recorded([string]$Program, [string[]]$Arguments) {
    $argumentString = $Arguments -join ' '
    $previousPreference = $ErrorActionPreference
    $code = $null
    $raw = ''
    $invocationError = ''
    $process = $null
    try {
        if ($Program -eq 'auditpol.exe') {
            # 显式传入参数字符串，避免 PowerShell 5.1 对花括号参数的原生命令封送影响。
            # 标准输出和错误异步读取，避免任一管道写满导致等待退出时死锁。
            $startInfo = New-Object System.Diagnostics.ProcessStartInfo
            $startInfo.FileName = $Program
            $startInfo.Arguments = $argumentString
            $startInfo.UseShellExecute = $false
            $startInfo.CreateNoWindow = $true
            $startInfo.RedirectStandardOutput = $true
            $startInfo.RedirectStandardError = $true
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $startInfo
            if (-not $process.Start()) { throw 'Process did not start.' }
            $stdoutTask = $process.StandardOutput.ReadToEndAsync()
            $stderrTask = $process.StandardError.ReadToEndAsync()
            $process.WaitForExit()
            $code = $process.ExitCode
            $raw = $stdoutTask.GetAwaiter().GetResult() + "`r`n" + $stderrTask.GetAwaiter().GetResult()
        } else {
            $ErrorActionPreference = 'Continue'
            $global:LASTEXITCODE = $null
            $nativeOutput = @(& $Program @Arguments 2>&1)
            $code = $global:LASTEXITCODE
            $raw = ($nativeOutput | ForEach-Object { [string]$_ }) -join "`r`n"
        }
    } catch {
        $invocationError = $_ | Out-String -Width 4096
    } finally {
        $ErrorActionPreference = $previousPreference
        if ($null -ne $process) { $process.Dispose() }
    }
    $classification = 'OTHER'
    $classificationText = $raw + "`r`n" + $invocationError
    if ($classificationText -match '(?i)0x00000522') { $classification = 'INSUFFICIENT_PRIVILEGE' }
    elseif ($classificationText -match '(?i)0x00000005') { $classification = 'ACCESS_DENIED' }
    elseif ($classificationText -match '(?i)0x00000057') { $classification = 'INVALID_PARAMETER' }
    elseif ($null -ne $code -and $code -eq 0 -and -not $invocationError) { $classification = 'OK' }
    $exitText = if ($null -eq $code) { 'NOT_STARTED' } else { [string]$code }
    Write-Detail ("Time={0}`r`nProgram={1}`r`nArguments={2}`r`n{3}`r`nExit={4}`r`nClassification={5}`r`nInvocationError={6}`r`n" -f (Get-Date).ToString('o'), $Program, $argumentString, $raw, $exitText, $classification, $invocationError)
    if ($Program -eq 'auditpol.exe' -and $Arguments[0] -eq '/list') {
        Write-Output "AuditDiagnostic Exit=$exitText Classification=$classification"
    } else {
        Write-Output "Command=$Program $argumentString Exit=$exitText Classification=$classification"
    }
    return [pscustomobject]@{ Raw = $raw; Code = $code; ExitText = $exitText; Classification = $classification; OK = ($classification -eq 'OK') }
}

function Get-MaxSize($Result) {
    if (-not $Result.OK) { return $null }
    $matchesFound = [regex]::Matches($Result.Raw, '(?im)^\s*maxSize\s*:\s*([0-9]+)\s*$')
    if ($matchesFound.Count -ne 1) { return $null }
    $parsed = [uint64]0
    if ([uint64]::TryParse($matchesFound[0].Groups[1].Value, [ref]$parsed)) { return $parsed }
    return $null
}

function Get-AuditSummary($Result) {
    $lines = @($Result.Raw -split '\r?\n' | Where-Object { $_.Trim().Length -gt 0 })
    if (-not $Result.OK -or $lines.Count -eq 0) { return 'UNKNOWN' }
    $value = $lines[-1].Trim()
    if ($value.Length -gt 160) { $value = $value.Substring(0, 160) }
    return $value
}

try {
    New-Item -ItemType Directory -Path $localRoot -Force -ErrorAction Stop | Out-Null
    Set-Content -LiteralPath $localFile -Value "Start=$($started.ToString('o'))`r`n=== BEFORE ===" -Encoding UTF8 -ErrorAction Stop
    Write-Output "Start=$($started.ToString('o')) Local=$localFile"

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        $isAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } finally { $identity.Dispose() }
    Write-Detail "IsAdministrator=$isAdministrator"
    Write-Output "IsAdministrator=$isAdministrator"
    $diagnosticItems = @(Invoke-Recorded 'auditpol.exe' @('/list', '/subcategory:*', '/v'))
    $diagnosticItems | Select-Object -SkipLast 1 | Write-Output

    # Capture and persist BOTH pre-change queries before any configuration.
    # Information stream redirection is not needed: the helper's short stdout
    # is separated from its result object here, preserving native exit codes.
    $beforeAuditItems = @(Invoke-Recorded 'auditpol.exe' @('/get', $subcategory))
    $beforeAudit = $beforeAuditItems[-1]
    $beforeAuditItems | Select-Object -SkipLast 1 | Write-Output
    $beforeLogItems = @(Invoke-Recorded 'wevtutil.exe' @('gl', 'Security'))
    $beforeLog = $beforeLogItems[-1]
    $beforeLogItems | Select-Object -SkipLast 1 | Write-Output
    $beforeSize = Get-MaxSize $beforeLog
    Write-Detail "BeforeMaxSize=$beforeSize"

    Write-Detail '=== CONFIGURATION ==='
    $auditSet = $null
    if ($beforeAudit.Classification -eq 'INVALID_PARAMETER') {
        $auditAction = 'FAILED: before query INVALID_PARAMETER; audit set skipped'
        Write-Detail $auditAction
        Write-Output $auditAction
    } else {
        $auditItems = @(Invoke-Recorded 'auditpol.exe' @('/set', $subcategory, '/failure:enable'))
        $auditSet = $auditItems[-1]
        $auditItems | Select-Object -SkipLast 1 | Write-Output
    }

    $sizeSet = $null
    $sizeAction = 'FAILED: current maxSize unavailable; no size change attempted'
    if ($null -ne $beforeSize) {
        if ($beforeSize -ge $minimum) {
            $sizeAction = '已满足、未改'
        } else {
            $sizeItems = @(Invoke-Recorded 'wevtutil.exe' @('sl', 'Security', "/ms:$minimum"))
            $sizeSet = $sizeItems[-1]
            $sizeItems | Select-Object -SkipLast 1 | Write-Output
            $sizeAction = "Requested=$minimum Exit=$($sizeSet.ExitText)"
        }
    }
    Write-Detail "SecuritySizeAction=$sizeAction"

    Write-Detail '=== AFTER ==='
    $afterAuditItems = @(Invoke-Recorded 'auditpol.exe' @('/get', $subcategory))
    $afterAudit = $afterAuditItems[-1]
    $afterAuditItems | Select-Object -SkipLast 1 | Write-Output
    $afterLogItems = @(Invoke-Recorded 'wevtutil.exe' @('gl', 'Security'))
    $afterLog = $afterLogItems[-1]
    $afterLogItems | Select-Object -SkipLast 1 | Write-Output
    $afterSize = Get-MaxSize $afterLog

    $auditOK = ($null -ne $auditSet -and $auditSet.OK -and $afterAudit.OK)
    $sizeOK = ($null -ne $beforeSize -and $null -ne $afterSize -and $afterSize -ge $minimum -and $afterSize -ge $beforeSize)
    if ($null -ne $sizeSet -and -not $sizeSet.OK) { $sizeOK = $false }
    $auditStatus = if ($auditOK) { 'SUCCESS (set accepted; raw policy recorded)' } else { 'FAILED (see command output/exit codes)' }
    $sizeStatus = if ($sizeOK) { 'SUCCESS' } else { 'FAILED (read/set/verification; see raw output)' }
    Write-Detail "Audit=$auditStatus`r`nSecuritySize=$sizeStatus`r`nBeforeMaxSize=$beforeSize AfterMaxSize=$afterSize`r`nSecuritySizeAction=$sizeAction"
    Write-Detail "EndLocal=$((Get-Date).ToString('o'))`r`nShareCopy=PENDING; final ShareCopy and EXIT appear in runner stdout."
    Write-Output "Audit=$auditStatus Before=[$(Get-AuditSummary $beforeAudit)] After=[$(Get-AuditSummary $afterAudit)]"
    Write-Output "SecuritySize=$sizeStatus Before=$beforeSize After=$afterSize Action=$sizeAction"

    $copied = $false
    $attempts = 0
    for ($attempt = 1; $attempt -le 6; $attempt++) {
        $attempts = $attempt
        try {
            New-Item -ItemType Directory -Path $share -Force -ErrorAction Stop | Out-Null
            Copy-Item -LiteralPath $localFile -Destination $share -Force -ErrorAction Stop
            $copied = $true
            break
        } catch {
            if ($attempt -lt 6) { [System.Threading.Thread]::Sleep(5000) }
        }
    }
    if (-not $copied) {
        Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile LocalComplete=True ShareCopy=False Attempts=$attempts EXIT=2"
        exit 2
    }
    Write-Output "ShareCopy=True Attempts=$attempts"
    # Failed configuration cannot claim the all-success exit code. Escalate
    # the fully recorded failure to the script-level exception handler.
    if (-not $auditOK -or -not $sizeOK) { throw 'Configuration failed; complete command results are in 71-config.txt.' }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile EXIT=0"
    exit 0
} catch {
    # Never change the local snapshot after a successful transfer.
    if (-not $copied) {
        try { Write-Detail ("ScriptException=" + ($_ | Out-String -Width 4096)) } catch { }
    }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile ScriptException=True EXIT=1"
    exit 1
}
