﻿# 面向 Windows PowerShell 5.1；本脚本仅在 Linux 上静态检查，未在 Windows 实际运行。
# 详细输出只写本地；共享拷贝完成后不再改写本地记录。
$ErrorActionPreference = 'Stop'
$started = Get-Date
$localRoot = 'C:\qa\tb4'
$localFile = Join-Path $localRoot '71-config.txt'
$share = '\\tsclient\tb\tb4\raw'
$subcategory = '/subcategory:{0CCE9215-69AE-11D9-BED3-505400000000}'
$minimum = [uint64]268435456

function Write-Detail([string]$Text) {
    Add-Content -LiteralPath $localFile -Value $Text -Encoding UTF8 -ErrorAction Stop
}

function Invoke-Recorded([string]$Program, [string[]]$Arguments) {
    # PS 5.1 may wrap native stderr in ErrorRecord. Continue captures it without
    # terminating before LASTEXITCODE can be saved; logging errors still stop.
    $previousPreference = $ErrorActionPreference
    $nativeOutput = @()
    $code = $null
    $invocationError = ''
    try {
        $ErrorActionPreference = 'Continue'
        $LASTEXITCODE = $null
        $nativeOutput = @(& $Program @Arguments 2>&1)
        $code = $LASTEXITCODE
    } catch {
        $invocationError = $_ | Out-String -Width 4096
    } finally {
        $ErrorActionPreference = $previousPreference
    }
    $raw = ($nativeOutput | ForEach-Object { [string]$_ }) -join "`r`n"
    $exitText = if ($null -eq $code) { 'NOT_STARTED' } else { [string]$code }
    Write-Detail ("Time={0}`r`nCommand={1} {2}`r`n{3}`r`nExit={4}`r`nInvocationError={5}`r`n" -f (Get-Date).ToString('o'), $Program, ($Arguments -join ' '), $raw, $exitText, $invocationError)
    Write-Output "Command=$Program $($Arguments -join ' ') Exit=$exitText"
    return [pscustomobject]@{ Raw = $raw; Code = $code; ExitText = $exitText; OK = ($null -ne $code -and $code -eq 0 -and -not $invocationError) }
}

function Get-MaxSize($Result) {
    if (-not $Result.OK) { return $null }
    $matchesFound = [regex]::Matches($Result.Raw, '(?im)^\s*maxSize\s*:\s*([0-9]+)\s*$')
    if ($matchesFound.Count -ne 1) { return $null }
    $parsed = [uint64]0
    if ([uint64]::TryParse($matchesFound[0].Groups[1].Value, [ref]$parsed)) { return $parsed }
    return $null
}

function Get-AuditSummary($Result) {
    $lines = @($Result.Raw -split '\r?\n' | Where-Object { $_.Trim().Length -gt 0 })
    if (-not $Result.OK -or $lines.Count -eq 0) { return 'UNKNOWN' }
    $value = $lines[-1].Trim()
    if ($value.Length -gt 160) { $value = $value.Substring(0, 160) }
    return $value
}

try {
    New-Item -ItemType Directory -Path $localRoot -Force -ErrorAction Stop | Out-Null
    Set-Content -LiteralPath $localFile -Value "Start=$($started.ToString('o'))`r`n=== BEFORE ===" -Encoding UTF8 -ErrorAction Stop
    Write-Output "Start=$($started.ToString('o')) Local=$localFile"

    # Capture and persist BOTH pre-change queries before any configuration.
    # Information stream redirection is not needed: the helper's short stdout
    # is separated from its result object here, preserving native exit codes.
    $beforeAuditItems = @(Invoke-Recorded 'auditpol.exe' @('/get', $subcategory))
    $beforeAudit = $beforeAuditItems[-1]
    $beforeAuditItems | Select-Object -SkipLast 1 | Write-Output
    $beforeLogItems = @(Invoke-Recorded 'wevtutil.exe' @('gl', 'Security'))
    $beforeLog = $beforeLogItems[-1]
    $beforeLogItems | Select-Object -SkipLast 1 | Write-Output
    $beforeSize = Get-MaxSize $beforeLog
    Write-Detail "BeforeMaxSize=$beforeSize"

    Write-Detail '=== CONFIGURATION ==='
    $auditItems = @(Invoke-Recorded 'auditpol.exe' @('/set', $subcategory, '/failure:enable'))
    $auditSet = $auditItems[-1]
    $auditItems | Select-Object -SkipLast 1 | Write-Output

    $sizeSet = $null
    $sizeAction = 'FAILED: current maxSize unavailable; no size change attempted'
    if ($null -ne $beforeSize) {
        if ($beforeSize -ge $minimum) {
            $sizeAction = '已满足、未改'
        } else {
            $sizeItems = @(Invoke-Recorded 'wevtutil.exe' @('sl', 'Security', "/ms:$minimum"))
            $sizeSet = $sizeItems[-1]
            $sizeItems | Select-Object -SkipLast 1 | Write-Output
            $sizeAction = "Requested=$minimum Exit=$($sizeSet.ExitText)"
        }
    }
    Write-Detail "SecuritySizeAction=$sizeAction"

    Write-Detail '=== AFTER ==='
    $afterAuditItems = @(Invoke-Recorded 'auditpol.exe' @('/get', $subcategory))
    $afterAudit = $afterAuditItems[-1]
    $afterAuditItems | Select-Object -SkipLast 1 | Write-Output
    $afterLogItems = @(Invoke-Recorded 'wevtutil.exe' @('gl', 'Security'))
    $afterLog = $afterLogItems[-1]
    $afterLogItems | Select-Object -SkipLast 1 | Write-Output
    $afterSize = Get-MaxSize $afterLog

    $auditOK = $auditSet.OK -and $afterAudit.OK
    $sizeOK = ($null -ne $beforeSize -and $null -ne $afterSize -and $afterSize -ge $minimum -and $afterSize -ge $beforeSize)
    if ($null -ne $sizeSet -and -not $sizeSet.OK) { $sizeOK = $false }
    $auditStatus = if ($auditOK) { 'SUCCESS (set accepted; raw policy recorded)' } else { 'FAILED (see command output/exit codes)' }
    $sizeStatus = if ($sizeOK) { 'SUCCESS' } else { 'FAILED (read/set/verification; see raw output)' }
    Write-Detail "Audit=$auditStatus`r`nSecuritySize=$sizeStatus`r`nBeforeMaxSize=$beforeSize AfterMaxSize=$afterSize`r`nSecuritySizeAction=$sizeAction"
    Write-Detail "EndLocal=$((Get-Date).ToString('o'))`r`nShareCopy=PENDING; final ShareCopy and EXIT appear in runner stdout."
    Write-Output "Audit=$auditStatus Before=[$(Get-AuditSummary $beforeAudit)] After=[$(Get-AuditSummary $afterAudit)]"
    Write-Output "SecuritySize=$sizeStatus Before=$beforeSize After=$afterSize Action=$sizeAction"

    $copied = $false
    $attempts = 0
    for ($attempt = 1; $attempt -le 6; $attempt++) {
        $attempts = $attempt
        try {
            New-Item -ItemType Directory -Path $share -Force -ErrorAction Stop | Out-Null
            Copy-Item -LiteralPath $localFile -Destination $share -Force -ErrorAction Stop
            $copied = $true
            break
        } catch {
            if ($attempt -lt 6) { [System.Threading.Thread]::Sleep(5000) }
        }
    }
    if (-not $copied) {
        Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile LocalComplete=True ShareCopy=False Attempts=$attempts EXIT=2"
        exit 2
    }
    Write-Output "ShareCopy=True Attempts=$attempts"
    # Failed configuration cannot claim the all-success exit code. Escalate
    # the fully recorded failure to the script-level exception handler.
    if (-not $auditOK -or -not $sizeOK) { throw 'Configuration failed; complete command results are in 71-config.txt.' }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile EXIT=0"
    exit 0
} catch {
    # Never change the local snapshot after a successful transfer.
    if (-not $copied) {
        try { Write-Detail ("ScriptException=" + ($_ | Out-String -Width 4096)) } catch { }
    }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile ScriptException=True EXIT=1"
    exit 1
}
