# v3-r1 解析规则与官方 CSV 结构（供 QA 交叉核对）

整理时间：2026-11-19 06:36 PST（America/Los_Angeles）。本轮未登录 Windows，未在目标机执行 auditpol/wevtutil，也未把下列公开资料当作目标机已核验结果。Linux pwsh 7.5.13 自测不等于 Windows PowerShell 5.1 或目标机验证。

GUID 对照仍以 `71-v3-delivery/docs/GUID-EVIDENCE.md` 为准。v3-r1 继续使用官方 Logon 子类 GUID `{0CCE9215-69AE-11D9-BED3-505054503030}`。

## 1. 本修订要堵住的语义空洞（冻结 v3）

独立 QA 对冻结 v3（sha256 `0b28973de68924c4de658ac9e55200ffd1cf8f9935e98c9290da86f92da31857`）的结论仍是 **16 pass / 4 fail**（`qa-71-v3-0b28973d/run.exit=1`）。本文件不改写该结论。

作者在未触碰 QA 目录的前提下，亲自用同一 `Run-QA.ps1`、同一冻结 v3 复现了这 4 个反例：`/get` exit 0 但输出仅为 `unrecognized output`、`System audit policy`、`Logon/Logoff` 时仍两写且 exit 0；`/list` 仅有官方 GUID、没有名称时仍两写且 exit 0。根因是：

- `Test-AuditValueParsed`（v3 行 92–96）在 exit 0 且非 usage/0x57 时，只要有任意非空行即视为已解析。
- `Test-OfficialLogonGuid`（v3 行 99–132）在官方 GUID 出现、且同一行未命中其它官方英文字类名时即确认；缺名称仍 `Confirmed=GUID_PRESENT`。

修订没有对这四个样例做字符串特判，而是改为一般规则。

## 2. 审核原值：只接受文档化的英文 inclusion setting

只承认 auditpol 在英文输出中的四种设定，并映射为 none / success / failure / both：

| 官方英文（大小写与多余空白可折叠后精确匹配） | Kind |
|---|---|
| No Auditing | None |
| Success | Success |
| Failure | Failure |
| Success and Failure | Both |

来源：Microsoft Learn [auditpol get](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/auditpol-get) 所述默认文本表（Category/Subcategory + Setting），以及同一页对 raw/CSV 格式下列名的说明：computer name, policy target, subcategory, subcategory GUID, inclusion settings, exclusion settings。

解析要求：

- 默认文本：必须出现名称字段精确为 `Logon` 且设定字段为上表之一的数据行。标题（如 System audit policy）、表头、类别名（如 Logon/Logoff）、垃圾输出、只有设定没有 Logon 名称、Logon 行缺设定、未知英文（如 Enabled）、本地化未确认值（如「失败」）、两行 Logon 设定互相冲突，一律不解析，全部不写。
- 若输出恰好是上述官方 CSV 列：按列读取。行必须指向本官方 Logon 子类（GUID 命中或 subcategory 精确为 Logon）；若 GUID 命中但名称存在且不是 Logon，视为不匹配；inclusion settings 必须是上表之一。未知值不得当作成功。
- `Get-AuditSummary` 仅在解析成功时报告「官方英文 [Kind]」；否则报告 `UNKNOWN`，不把标题或垃圾输出伪装成已解析原值。

未把「登录 / 无审核 / 失败」等本地化词编进脚本。目标机若为非英文 auditpol 输出，写入门仍应保持关闭，直到另有经官方或目标机核验的名称表；那是后续前置条件，不在本修订写入范围。

## 3. /list：官方 GUID 必须与名称 Logon 明确对应

确认条件（同时满足）：

- `/list /subcategory:* /v` 分类为 OK。
- 官方 GUID 至少出现一次。
- 每一次命中提取到的子类名称，折叠空白后都精确等于 `Logon`（忽略大小写）。

下列全部不确认、全部不写：仅 GUID、空白加 GUID、缺名称、类别名当作子类名、其它子类名（包括 Special Logon 等）、本地化未确认名称、同一 GUID 对应多个不同名称、同一 GUID 既有 Logon 又有空名称（歧义）。

不再使用「GUID 在、且没碰到其它官方英文名」这种缺省确认。

文本行：从命中行去掉 GUID 与花括号后的剩余标签即名称。官方 CSV（含 subcategory 与 subcategory GUID 列）优先按列提取。不根据上一行类别标题去猜测缺名称的 GUID 行。

## 4. 命令与配置范围（未扩大）

- 只读命令仍是 `auditpol /list /subcategory:* /v` 与 `auditpol /get /subcategory:{官方GUID}`，以及 `wevtutil gl Security`。
- 写入仍只在两项原值都解析有效且 GUID+Logon 名称确认之后：`auditpol /set /subcategory:{官方GUID} /failure:enable`（无 success 开关），以及在 maxSize 低于 268435456 时 `wevtutil sl Security /ms:268435456`。不缩小、不清理、不改保留/溢出参数。
- 脚本命令行没有增加 raw/CSV 开关。PROMPT-71 禁止把该开关传给 `wevtutil sl`；PROMPT-71b 静态检查也不允许脚本出现该开关字面量。因此 r1 只在输出恰好已是官方 CSV 时解析该结构。
- 退出码约定与原范围相同：0 全成功且复制成功；2 复制失败；1 脚本/配置失败（复制已记录时）。

## 5. 本轮未做的事

未登录、未恢复作业通道、未上机、未写 Windows 配置、未回退、未发布产品。目标机 `/list` 对照仍未核验，公开资料不能代替该机只读列表。
