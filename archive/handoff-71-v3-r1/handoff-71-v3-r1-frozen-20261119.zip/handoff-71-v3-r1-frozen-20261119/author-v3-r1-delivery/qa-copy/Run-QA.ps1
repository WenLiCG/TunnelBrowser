# Public test entry for 71 v3 write-gate behavior.
# Invokes the real script under test via pwsh -File. Assertions count stub journal
# entries for auditpol /set and wevtutil sl only. Does not copy script branch logic.
param(
    [Parameter(Mandatory = $true)]
    [string]$ScriptUnderTest,
    [string]$EvidenceFile = ''
)

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$stubPy = '/workspace/tunnelbrowser/tbshare/tb4/jobs/71-v3-delivery/tests/stubs/tool_stub.py'
$python = (Get-Command python3).Source
$officialGuid = '0CCE9215-69AE-11D9-BED3-505054503030'
$scriptGuidTypo = '0CCE9215-69AE-11D9-BED3-505400000000'

$glSmall = @"
name: Security
enabled: true
type: Admin
owningPublisher: 
isolation: Custom
channelAccess: O:BAG:SYD:(A;;0xf0005;;;SY)
logging:
  logFileName: %SystemRoot%\System32\Winevt\Logs\Security.evtx
  retention: false
  autoBackup: false
  maxSize: 20971520
publishing:
  fileMax: 1
"@

$glLarge = $glSmall -replace 'maxSize: 20971520', 'maxSize: 268435456'
$glNoMax = @"
name: Security
enabled: true
type: Admin
logging:
  retention: false
  autoBackup: false
publishing:
  fileMax: 1
"@

$getFailure = @"
System audit policy
Category/Subcategory                      Setting
Logon/Logoff
  Logon                                   Failure
"@

$getNoAuditing = @"
System audit policy
Category/Subcategory                      Setting
Logon/Logoff
  Logon                                   No Auditing
"@

$usage = @"
用法: AuditPol command [<sub-command><options>]


发生错误 0x00000057:
"@

$priv = @"
发生错误 0x00000522:
无法完成操作。缺少所需特权。
"@

function New-ListText([string]$Guid, [string]$Label) {
    return @"
Category/Subcategory                      GUID
Logon/Logoff
  $Label                               {$Guid}
  Logoff                               {0CCE9216-69AE-11D9-BED3-505054503030}
"@
}

$passed = 0
$failed = 0
$results = @()

function Write-Result([string]$Name, [bool]$Ok, [string]$Detail) {
    $script:results += [pscustomobject]@{ Name = $Name; OK = $Ok; Detail = $Detail }
    if ($Ok) {
        $script:passed++
        Write-Output "PASS $Name"
    } else {
        $script:failed++
        Write-Output "FAIL $Name :: $Detail"
    }
    if ($Detail) { Write-Output "  $Detail" }
}

function Invoke-Case {
    param(
        [string]$Name,
        [hashtable]$Scenario,
        [scriptblock]$Assert,
        [switch]$OmitAuditpol,
        [switch]$OmitWevtutil,
        [switch]$BreakShare
    )
    $root = Join-Path ([IO.Path]::GetTempPath()) ("tb71v3-" + [guid]::NewGuid().ToString('n'))
    $local = Join-Path $root 'local'
    $share = Join-Path $root 'share'
    $bin = Join-Path $root 'bin'
    $journal = Join-Path $root 'journal.jsonl'
    $scenarioFile = Join-Path $root 'scenario.json'
    New-Item -ItemType Directory -Force -Path $local, $share, $bin | Out-Null
    Set-Content -LiteralPath $scenarioFile -Value ($Scenario | ConvertTo-Json -Depth 8) -Encoding UTF8
    if (-not $OmitAuditpol) {
        $auditpol = Join-Path $bin 'auditpol.exe'
        New-Item -ItemType SymbolicLink -Path $auditpol -Target $python | Out-Null
        # python3 shebang won't run as auditpol.exe; use wrapper
        Remove-Item -LiteralPath $auditpol -Force
        $wrapper = @"
#!/usr/bin/env bash
exec "$python" "$stubPy" "\$@"
"@
        # The above escapes wrong; write carefully below
    }
    $wrapperTemplate = @'
#!/usr/bin/env bash
export TB71_STUB_PROGRAM=PROGRAM_PLACEHOLDER
export PYTHONUNBUFFERED=1
exec 'PYTHON_PLACEHOLDER' 'STUB_PLACEHOLDER' "$@"
'@
    $wrapperTemplate = $wrapperTemplate.Replace('PYTHON_PLACEHOLDER', $python).Replace('STUB_PLACEHOLDER', $stubPy)
    function Write-Wrapper([string]$Path, [string]$Program) {
        $text = $wrapperTemplate.Replace('PROGRAM_PLACEHOLDER', $Program)
        Set-Content -LiteralPath $Path -Value $text -Encoding utf8NoBOM
        & chmod +x $Path
    }
    if (-not $OmitAuditpol) { Write-Wrapper (Join-Path $bin 'auditpol.exe') 'auditpol.exe' }
    if (-not $OmitWevtutil) { Write-Wrapper (Join-Path $bin 'wevtutil.exe') 'wevtutil.exe' }
    if ($BreakShare) {
        Remove-Item -LiteralPath $share -Recurse -Force -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $share -Value 'not-a-directory' -Encoding utf8NoBOM
    }

    $env:TB71_LOCAL_ROOT = $local
    $env:TB71_SHARE = $(if ($BreakShare) { Join-Path $share 'raw' } else { $share })
    $env:TB71_JOURNAL = $journal
    $env:TB71_SCENARIO = $scenarioFile
    $env:TB71_IS_ADMINISTRATOR = '1'
    $env:TB71_AUDITPOL = $(if ($OmitAuditpol) { 'auditpol.exe' } else { Join-Path $bin 'auditpol.exe' })
    $env:TB71_WEVTUTIL = $(if ($OmitWevtutil) { 'wevtutil.exe' } else { Join-Path $bin 'wevtutil.exe' })
    $stdoutFile = Join-Path $root 'stdout.txt'
    $stderrFile = Join-Path $root 'stderr.txt'
    $pwsh = (Get-Command pwsh).Source
    $proc = Start-Process -FilePath $pwsh -ArgumentList @('-NoProfile', '-File', $ScriptUnderTest) -Wait -PassThru -NoNewWindow -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile
    $exitCode = $proc.ExitCode
    $journalLines = @()
    if (Test-Path -LiteralPath $journal) {
        $journalLines = @(Get-Content -LiteralPath $journal -Encoding UTF8 | Where-Object { $_.Trim().Length -gt 0 } | ForEach-Object { $_ | ConvertFrom-Json })
    }
    function Test-ArgMatch($entry, [string]$Token) {
        $list = @($entry.args | ForEach-Object { [string]$_ })
        if ($list -contains $Token) { return $true }
        if ($list.Count -eq 1 -and ($list[0] -split '\s+') -contains $Token) { return $true }
        return $false
    }
    $writeSet = @($journalLines | Where-Object { (Test-ArgMatch $_ '/set') })
    $writeSl = @($journalLines | Where-Object { (Test-ArgMatch $_ 'sl') })
    $info = [pscustomobject]@{
        Name = $Name
        Root = $root
        ExitCode = $exitCode
        Journal = $journalLines
        WriteSet = $writeSet
        WriteSl = $writeSl
        WriteCount = ($writeSet.Count + $writeSl.Count)
        StdOut = (Get-Content -LiteralPath $stdoutFile -Encoding UTF8 -ErrorAction SilentlyContinue) -join "`n"
        StdErr = (Get-Content -LiteralPath $stderrFile -Encoding UTF8 -ErrorAction SilentlyContinue) -join "`n"
        LocalFile = Join-Path $local '71-config.txt'
    }
    try {
        & $Assert $info
    } catch {
        Write-Result $Name $false ($_ | Out-String)
    }
}

function Expect-ZeroWrites($info, [string]$Name) {
    if ($info.WriteCount -eq 0) {
        Write-Result $Name $true ("writes=0 exit=$($info.ExitCode) set=$($info.WriteSet.Count) sl=$($info.WriteSl.Count)")
    } else {
        $detail = "writes=$($info.WriteCount) set=$($info.WriteSet.Count) sl=$($info.WriteSl.Count) exit=$($info.ExitCode) journal=$($info.Journal | ConvertTo-Json -Compress)"
        Write-Result $Name $false $detail
    }
}

# --- default happy pieces ---
$okListOfficial = New-ListText $officialGuid 'Logon'
$okListTypoOnly = New-ListText $scriptGuidTypo 'Logon'
$mismatchLabel = New-ListText $officialGuid 'Logoff'

$baseOk = @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'The command was successfully executed.'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = ''; stderr = '' }
}

Invoke-Case 'T01_list_privilege_insufficient_zero_writes' @{
    list = @{ exit = 1; stdout = ''; stderr = $priv }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T01_list_privilege_insufficient_zero_writes' }

Invoke-Case 'T02_get_privilege_insufficient_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 1; stdout = ''; stderr = $priv }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T02_get_privilege_insufficient_zero_writes' }

Invoke-Case 'T03_auditpol_start_failure_zero_writes' $baseOk { param($i) Expect-ZeroWrites $i 'T03_auditpol_start_failure_zero_writes' } -OmitAuditpol

Invoke-Case 'T04_wevtutil_start_failure_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T04_wevtutil_start_failure_zero_writes' } -OmitWevtutil

Invoke-Case 'T05_maxsize_malformed_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glNoMax; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T05_maxsize_malformed_zero_writes' }

Invoke-Case 'T06_maxsize_empty_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = ''; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T06_maxsize_empty_zero_writes' }

Invoke-Case 'T07_audit_get_malformed_usage_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $usage; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T07_audit_get_malformed_usage_zero_writes' }

Invoke-Case 'T08_guid_list_failed_zero_writes' @{
    list = @{ exit = 1; stdout = ''; stderr = '发生错误 0x00000057:' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T08_guid_list_failed_zero_writes' }

Invoke-Case 'T09_guid_absent_typo_only_zero_writes' @{
    list = @{ exit = 0; stdout = $okListTypoOnly; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T09_guid_absent_typo_only_zero_writes' }

Invoke-Case 'T10_guid_label_mismatch_zero_writes' @{
    list = @{ exit = 0; stdout = $mismatchLabel; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T10_guid_label_mismatch_zero_writes' }

Invoke-Case 'T11_size_unreadable_audit_ok_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 1; stdout = ''; stderr = 'Access is denied. 0x00000005' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T11_size_unreadable_audit_ok_zero_writes' }

Invoke-Case 'T12_audit_fail_size_ok_zero_writes' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 1; stdout = ''; stderr = $priv }
    set  = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} { param($i) Expect-ZeroWrites $i 'T12_audit_fail_size_ok_zero_writes' }

Invoke-Case 'T13_both_ok_size_below_writes_set_and_sl' $baseOk {
    param($i)
    $setOk = ($i.WriteSet.Count -eq 1)
    $slOk = ($i.WriteSl.Count -eq 1)
    $exitOk = ($i.ExitCode -eq 0)
    $guidOnSet = $false
    if ($setOk) {
        $argstr = ($i.WriteSet[0].args -join ' ')
        $guidOnSet = $argstr -match [regex]::Escape($officialGuid)
        $noSuccess = $argstr -notmatch '/success'
        $failure = $argstr -match '/failure:enable'
    }
    if ($setOk -and $slOk -and $exitOk -and $guidOnSet -and $noSuccess -and $failure) {
        Write-Result 'T13_both_ok_size_below_writes_set_and_sl' $true "exit=0 set=1 sl=1 officialGUID=/set no /success"
    } else {
        Write-Result 'T13_both_ok_size_below_writes_set_and_sl' $false "exit=$($i.ExitCode) set=$($i.WriteSet.Count) sl=$($i.WriteSl.Count) guidOnSet=$guidOnSet stdout=$($i.StdOut)"
    }
}

Invoke-Case 'T14_both_ok_size_already_met_set_no_sl' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getFailure; stderr = '' }
    set  = @{ exit = 0; stdout = 'The command was successfully executed.'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glLarge; stderr = '' }
    sl   = @{ exit = 0; stdout = 'should-not-run'; stderr = '' }
} {
    param($i)
    $ok = ($i.WriteSet.Count -eq 1 -and $i.WriteSl.Count -eq 0 -and $i.ExitCode -eq 0 -and ($i.StdOut -match '已满足、未改'))
    if ($ok) { Write-Result 'T14_both_ok_size_already_met_set_no_sl' $true 'exit=0 set=1 sl=0 idempotent size' }
    else { Write-Result 'T14_both_ok_size_already_met_set_no_sl' $false "exit=$($i.ExitCode) set=$($i.WriteSet.Count) sl=$($i.WriteSl.Count) stdout=$($i.StdOut)" }
}

Invoke-Case 'T15_set_fails_copy_ok_exit_1' @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 1; stdout = ''; stderr = $priv }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = ''; stderr = '' }
} {
    param($i)
    $ok = ($i.ExitCode -eq 1 -and $i.WriteSet.Count -eq 1)
    if ($ok) { Write-Result 'T15_set_fails_copy_ok_exit_1' $true "exit=1 set=1 (write attempted after successful reads) sl=$($i.WriteSl.Count)" }
    else { Write-Result 'T15_set_fails_copy_ok_exit_1' $false "exit=$($i.ExitCode) set=$($i.WriteSet.Count) sl=$($i.WriteSl.Count) stdout=$($i.StdOut)" }
}

Invoke-Case 'T16_copy_fails_exit_2' $baseOk {
    param($i)
    $ok = ($i.ExitCode -eq 2 -and ($i.StdOut -match 'ShareCopy=False' -or $i.StdOut -match 'EXIT=2'))
    if ($ok) { Write-Result 'T16_copy_fails_exit_2' $true "exit=2 ShareCopy=False" }
    else { Write-Result 'T16_copy_fails_exit_2' $false "exit=$($i.ExitCode) stdout=$($i.StdOut) stderr=$($i.StdErr)" }
} -BreakShare


foreach ($bad in @('unrecognized output', 'System audit policy', 'Logon/Logoff')) {
    $case = $baseOk.Clone()
    $case.get = @{ exit = 0; stdout = $bad; stderr = '' }
    Invoke-Case ('QA_malformed_audit_' + $bad) $case { param($i) Expect-ZeroWrites $i $i.Name }
}
$case = $baseOk.Clone()
$case.list = @{ exit = 0; stdout = $officialGuid; stderr = '' }
Invoke-Case 'QA_list_guid_without_label' $case { param($i) Expect-ZeroWrites $i $i.Name }

Write-Output ('----- summary -----')
Write-Output ("ScriptUnderTest=$ScriptUnderTest")
Write-Output ("Passed=$passed Failed=$failed Total=$($passed + $failed)")
if ($EvidenceFile) {
    $results | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($EvidenceFile + '.results.json') -Encoding UTF8
}
if ($failed -gt 0) { exit 1 } else { exit 0 }
