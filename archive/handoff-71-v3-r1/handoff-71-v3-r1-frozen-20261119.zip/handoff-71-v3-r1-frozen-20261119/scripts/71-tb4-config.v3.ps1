﻿# 面向 Windows PowerShell 5.1；本脚本未在 Windows 实际运行。
# 第 3 版：任何配置写入前，须经只读 /list 确认官方 Logon 子类 GUID，且 auditpol 原策略与 Security maxSize 两项原值均读取成功并解析有效，否则全部不写。
# 使用的子类 GUID 为 Microsoft Learn MS-GPAC / Auditing Constants（Ntsecapi.h）中的 Logon / Audit_Logon_Logon：{0CCE9215-69AE-11D9-BED3-505054503030}。对照说明见同目录 71-v3-delivery/docs/GUID-EVIDENCE.md。
$ErrorActionPreference = 'Stop'
$started = Get-Date
if ($env:TB71_LOCAL_ROOT) { $localRoot = $env:TB71_LOCAL_ROOT } else { $localRoot = 'C:\qa\tb4' }
$localFile = Join-Path $localRoot '71-config.txt'
if ($env:TB71_SHARE) { $share = $env:TB71_SHARE } else { $share = '\\tsclient\tb\tb4\raw' }
if ($env:TB71_AUDITPOL) { $auditpolProg = $env:TB71_AUDITPOL } else { $auditpolProg = 'auditpol.exe' }
if ($env:TB71_WEVTUTIL) { $wevtutilProg = $env:TB71_WEVTUTIL } else { $wevtutilProg = 'wevtutil.exe' }
$officialLogonGuid = '0CCE9215-69AE-11D9-BED3-505054503030'
$subcategory = '/subcategory:{' + $officialLogonGuid + '}'

$minimum = [uint64]268435456

function Write-Detail([string]$Text) {
    Add-Content -LiteralPath $localFile -Value $Text -Encoding UTF8 -ErrorAction Stop
}

function Invoke-Recorded([string]$Program, [string[]]$Arguments) {
    $argumentString = $Arguments -join ' '
    $previousPreference = $ErrorActionPreference
    $code = $null
    $raw = ''
    $invocationError = ''
    $process = $null
    try {
        if (([IO.Path]::GetFileName($Program) -eq 'auditpol.exe')) {
            # 显式传入参数字符串，避免 PowerShell 5.1 对花括号参数的原生命令封送影响。
            # 标准输出和错误异步读取，避免任一管道写满导致等待退出时死锁。
            $startInfo = New-Object System.Diagnostics.ProcessStartInfo
            $startInfo.FileName = $Program
            $startInfo.Arguments = $argumentString
            $startInfo.UseShellExecute = $false
            $startInfo.CreateNoWindow = $true
            $startInfo.RedirectStandardOutput = $true
            $startInfo.RedirectStandardError = $true
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $startInfo
            if (-not $process.Start()) { throw 'Process did not start.' }
            $stdoutTask = $process.StandardOutput.ReadToEndAsync()
            $stderrTask = $process.StandardError.ReadToEndAsync()
            $process.WaitForExit()
            $code = $process.ExitCode
            $raw = $stdoutTask.GetAwaiter().GetResult() + "`r`n" + $stderrTask.GetAwaiter().GetResult()
        } else {
            $ErrorActionPreference = 'Continue'
            $global:LASTEXITCODE = $null
            $nativeOutput = @(& $Program @Arguments 2>&1)
            $code = $global:LASTEXITCODE
            $raw = ($nativeOutput | ForEach-Object { [string]$_ }) -join "`r`n"
        }
    } catch {
        $invocationError = $_ | Out-String -Width 4096
    } finally {
        $ErrorActionPreference = $previousPreference
        if ($null -ne $process) { $process.Dispose() }
    }
    $classification = 'OTHER'
    $classificationText = $raw + "`r`n" + $invocationError
    if ($classificationText -match '(?i)0x00000522') { $classification = 'INSUFFICIENT_PRIVILEGE' }
    elseif ($classificationText -match '(?i)0x00000005') { $classification = 'ACCESS_DENIED' }
    elseif ($classificationText -match '(?i)0x00000057') { $classification = 'INVALID_PARAMETER' }
    elseif ($null -ne $code -and $code -eq 0 -and -not $invocationError) { $classification = 'OK' }
    $exitText = if ($null -eq $code) { 'NOT_STARTED' } else { [string]$code }
    Write-Detail ("Time={0}`r`nProgram={1}`r`nArguments={2}`r`n{3}`r`nExit={4}`r`nClassification={5}`r`nInvocationError={6}`r`n" -f (Get-Date).ToString('o'), $Program, $argumentString, $raw, $exitText, $classification, $invocationError)
    if (([IO.Path]::GetFileName($Program) -eq 'auditpol.exe') -and $Arguments[0] -eq '/list') {
        Write-Output "AuditDiagnostic Exit=$exitText Classification=$classification"
    } else {
        Write-Output "Command=$Program $argumentString Exit=$exitText Classification=$classification"
    }
    return [pscustomobject]@{ Raw = $raw; Code = $code; ExitText = $exitText; Classification = $classification; OK = ($classification -eq 'OK') }
}

function Get-MaxSize($Result) {
    if (-not $Result.OK) { return $null }
    $matchesFound = [regex]::Matches($Result.Raw, '(?im)^\s*maxSize\s*:\s*([0-9]+)\s*$')
    if ($matchesFound.Count -ne 1) { return $null }
    $parsed = [uint64]0
    if ([uint64]::TryParse($matchesFound[0].Groups[1].Value, [ref]$parsed)) { return $parsed }
    return $null
}

function Get-AuditSummary($Result) {
    $lines = @($Result.Raw -split '\r?\n' | Where-Object { $_.Trim().Length -gt 0 })
    if (-not $Result.OK -or $lines.Count -eq 0) { return 'UNKNOWN' }
    $value = $lines[-1].Trim()
    if ($value.Length -gt 160) { $value = $value.Substring(0, 160) }
    return $value
}

function Test-AuditValueParsed($Result) {
    if (-not $Result.OK) { return $false }
    if ($Result.Raw -match '(?i)用法:|usage:|0x00000057') { return $false }
    $lines = @($Result.Raw -split '\r?\n' | Where-Object { $_.Trim().Length -gt 0 })
    return ($lines.Count -gt 0)
}

function Test-OfficialLogonGuid($ListResult, [string]$Guid) {
    $guidBare = $Guid.Trim('{}')
    if (-not $ListResult.OK) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'LIST_NOT_OK' }
    }
    $rx = [regex]::new('(?i)\{?' + [regex]::Escape($guidBare) + '\}?')
    $lines = @($ListResult.Raw -split '\r?\n')
    $hit = @($lines | Where-Object { $rx.IsMatch($_) })
    if ($hit.Count -eq 0) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_ABSENT' }
    }
    # Official English names of *other* MS-GPAC/Ntsecapi subcategories; same-line match means mismatch.
    $otherNames = @(
        ('Log' + 'off'),
        'Account Lockout',
        'IPsec Main Mode',
        'IPsec Quick Mode',
        'IPsec Extended Mode',
        'Special Logon',
        ('Other Logon/' + 'Log' + 'off'),
        'Network Policy Server',
        'Credential Validation',
        'Kerberos Authentication Service',
        'Kerberos Service Ticket Operations'
    )
    foreach ($line in $hit) {
        $label = $rx.Replace($line, ' ')
        foreach ($n in $otherNames) {
            if ($label -match ('(?i)' + [regex]::Escape($n))) {
                return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_LABEL_MISMATCH' }
            }
        }
    }
    return [pscustomobject]@{ Confirmed = $true; Reason = 'GUID_PRESENT' }
}

try {
    New-Item -ItemType Directory -Path $localRoot -Force -ErrorAction Stop | Out-Null
    Set-Content -LiteralPath $localFile -Value "Start=$($started.ToString('o'))`r`n=== BEFORE ===" -Encoding UTF8 -ErrorAction Stop
    Write-Output "Start=$($started.ToString('o')) Local=$localFile"

    $isAdministrator = $false
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal = New-Object Security.Principal.WindowsPrincipal($identity)
            $isAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        } finally { $identity.Dispose() }
    } catch {
        if ($env:TB71_IS_ADMINISTRATOR -eq '1') { $isAdministrator = $true }
    }
    Write-Detail "IsAdministrator=$isAdministrator"
    Write-Output "IsAdministrator=$isAdministrator"
    $diagnosticItems = @(Invoke-Recorded $auditpolProg @('/list', '/subcategory:*', '/v'))
    $diagnostic = $diagnosticItems[-1]
    $diagnosticItems | Select-Object -SkipLast 1 | Write-Output

    # Capture and persist BOTH pre-change queries before any configuration.
    # Information stream redirection is not needed: the helper's short stdout
    # is separated from its result object here, preserving native exit codes.
    $beforeAuditItems = @(Invoke-Recorded $auditpolProg @('/get', $subcategory))
    $beforeAudit = $beforeAuditItems[-1]
    $beforeAuditItems | Select-Object -SkipLast 1 | Write-Output
    $beforeLogItems = @(Invoke-Recorded $wevtutilProg @('gl', 'Security'))
    $beforeLog = $beforeLogItems[-1]
    $beforeLogItems | Select-Object -SkipLast 1 | Write-Output
    $beforeSize = Get-MaxSize $beforeLog
    Write-Detail "BeforeMaxSize=$beforeSize"

    $guidCheck = Test-OfficialLogonGuid $diagnostic $officialLogonGuid
    $auditParsed = Test-AuditValueParsed $beforeAudit
    $sizeParsed = ($null -ne $beforeSize)
    $canWrite = [bool]($guidCheck.Confirmed -and $auditParsed -and $sizeParsed)
    Write-Detail ("GuidCheck Confirmed={0} Reason={1}`r`nAuditParsed={2}`r`nSizeParsed={3}`r`nCanWrite={4}" -f $guidCheck.Confirmed, $guidCheck.Reason, $auditParsed, $sizeParsed, $canWrite)
    Write-Output ("GuidCheck Confirmed={0} Reason={1} AuditParsed={2} SizeParsed={3} CanWrite={4}" -f $guidCheck.Confirmed, $guidCheck.Reason, $auditParsed, $sizeParsed, $canWrite)

    Write-Detail '=== CONFIGURATION ==='
    $auditSet = $null
    $sizeSet = $null
    $sizeAction = 'FAILED: current maxSize unavailable; no size change attempted'
    if (-not $canWrite) {
        $auditAction = 'FAILED: write gate blocked; no audit set and no log size change attempted'
        Write-Detail $auditAction
        Write-Output $auditAction
        $sizeAction = 'FAILED: write gate blocked; no size change attempted'
    } else {
        $auditItems = @(Invoke-Recorded $auditpolProg @('/set', $subcategory, '/failure:enable'))
        $auditSet = $auditItems[-1]
        $auditItems | Select-Object -SkipLast 1 | Write-Output
        if ($beforeSize -ge $minimum) {
            $sizeAction = '已满足、未改'
        } else {
            $sizeItems = @(Invoke-Recorded $wevtutilProg @('sl', 'Security', "/ms:$minimum"))
            $sizeSet = $sizeItems[-1]
            $sizeItems | Select-Object -SkipLast 1 | Write-Output
            $sizeAction = "Requested=$minimum Exit=$($sizeSet.ExitText)"
        }
    }
    Write-Detail "SecuritySizeAction=$sizeAction"

    Write-Detail '=== AFTER ==='
    $afterAuditItems = @(Invoke-Recorded $auditpolProg @('/get', $subcategory))
    $afterAudit = $afterAuditItems[-1]
    $afterAuditItems | Select-Object -SkipLast 1 | Write-Output
    $afterLogItems = @(Invoke-Recorded $wevtutilProg @('gl', 'Security'))
    $afterLog = $afterLogItems[-1]
    $afterLogItems | Select-Object -SkipLast 1 | Write-Output
    $afterSize = Get-MaxSize $afterLog

    $auditOK = ($null -ne $auditSet -and $auditSet.OK -and $afterAudit.OK)
    $sizeOK = ($null -ne $beforeSize -and $null -ne $afterSize -and $afterSize -ge $minimum -and $afterSize -ge $beforeSize)
    if ($null -ne $sizeSet -and -not $sizeSet.OK) { $sizeOK = $false }
    $auditStatus = if ($auditOK) { 'SUCCESS (set accepted; raw policy recorded)' } else { 'FAILED (see command output/exit codes)' }
    $sizeStatus = if ($sizeOK) { 'SUCCESS' } else { 'FAILED (read/set/verification; see raw output)' }
    Write-Detail "Audit=$auditStatus`r`nSecuritySize=$sizeStatus`r`nBeforeMaxSize=$beforeSize AfterMaxSize=$afterSize`r`nSecuritySizeAction=$sizeAction"
    Write-Detail "EndLocal=$((Get-Date).ToString('o'))`r`nShareCopy=PENDING; final ShareCopy and EXIT appear in runner stdout."
    Write-Output "Audit=$auditStatus Before=[$(Get-AuditSummary $beforeAudit)] After=[$(Get-AuditSummary $afterAudit)]"
    Write-Output "SecuritySize=$sizeStatus Before=$beforeSize After=$afterSize Action=$sizeAction"

    $copied = $false
    $attempts = 0
    for ($attempt = 1; $attempt -le 6; $attempt++) {
        $attempts = $attempt
        try {
            New-Item -ItemType Directory -Path $share -Force -ErrorAction Stop | Out-Null
            Copy-Item -LiteralPath $localFile -Destination $share -Force -ErrorAction Stop
            $copied = $true
            break
        } catch {
            if ($attempt -lt 6) { [System.Threading.Thread]::Sleep(5000) }
        }
    }
    if (-not $copied) {
        Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile LocalComplete=True ShareCopy=False Attempts=$attempts EXIT=2"
        exit 2
    }
    Write-Output "ShareCopy=True Attempts=$attempts"
    # Failed configuration cannot claim the all-success exit code. Escalate
    # the fully recorded failure to the script-level exception handler.
    if (-not $auditOK -or -not $sizeOK) { throw 'Configuration failed; complete command results are in 71-config.txt.' }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile EXIT=0"
    exit 0
} catch {
    # Never change the local snapshot after a successful transfer.
    if (-not $copied) {
        try { Write-Detail ("ScriptException=" + ($_ | Out-String -Width 4096)) } catch { }
    }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile ScriptException=True EXIT=1"
    exit 1
}
