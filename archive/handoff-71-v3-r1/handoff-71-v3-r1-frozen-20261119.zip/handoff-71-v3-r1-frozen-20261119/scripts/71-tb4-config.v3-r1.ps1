﻿# 面向 Windows PowerShell 5.1；本脚本未在 Windows 实际运行。
# 第 3 版修订 r1：任何配置写入前，须经只读 /list 确认官方 Logon 子类 GUID，且同一条目带有与该 GUID 明确对应的子类名称 Logon（精确匹配，忽略大小写与多余空白）；同时 auditpol 原策略须解析为官方英文设定之一（No Auditing、Success、Failure、Success and Failure，对应 none、success、failure、both），且 Security maxSize 原值读取并解析有效。标题、垃圾输出、仅 GUID、缺名称、名称不匹配、歧义、未知或未确认的本地化值全部不写。未知不得当作成功。
# 使用的子类 GUID 为 Microsoft Learn MS-GPAC / Auditing Constants（Ntsecapi.h）中的 Logon / Audit_Logon_Logon：{0CCE9215-69AE-11D9-BED3-505054503030}。对照说明见 71-v3-delivery/docs/GUID-EVIDENCE.md 与 71-v3-r1-delivery/docs/。命令行保持原只读 /list 与 /get，以及原写入范围，不增加 CSV 开关参数；若输出恰好为微软文档所列 official CSV 列（computer name, policy target, subcategory, subcategory GUID, inclusion settings, exclusion settings），则按该结构解析。
$ErrorActionPreference = 'Stop'
$started = Get-Date
if ($env:TB71_LOCAL_ROOT) { $localRoot = $env:TB71_LOCAL_ROOT } else { $localRoot = 'C:\qa\tb4' }
$localFile = Join-Path $localRoot '71-config.txt'
if ($env:TB71_SHARE) { $share = $env:TB71_SHARE } else { $share = '\\tsclient\tb\tb4\raw' }
if ($env:TB71_AUDITPOL) { $auditpolProg = $env:TB71_AUDITPOL } else { $auditpolProg = 'auditpol.exe' }
if ($env:TB71_WEVTUTIL) { $wevtutilProg = $env:TB71_WEVTUTIL } else { $wevtutilProg = 'wevtutil.exe' }
$officialLogonGuid = '0CCE9215-69AE-11D9-BED3-505054503030'
$subcategory = '/subcategory:{' + $officialLogonGuid + '}'

$minimum = [uint64]268435456

function Write-Detail([string]$Text) {
    Add-Content -LiteralPath $localFile -Value $Text -Encoding UTF8 -ErrorAction Stop
}

function Invoke-Recorded([string]$Program, [string[]]$Arguments) {
    $argumentString = $Arguments -join ' '
    $previousPreference = $ErrorActionPreference
    $code = $null
    $raw = ''
    $invocationError = ''
    $process = $null
    try {
        if (([IO.Path]::GetFileName($Program) -eq 'auditpol.exe')) {
            # 显式传入参数字符串，避免 PowerShell 5.1 对花括号参数的原生命令封送影响。
            # 标准输出和错误异步读取，避免任一管道写满导致等待退出时死锁。
            $startInfo = New-Object System.Diagnostics.ProcessStartInfo
            $startInfo.FileName = $Program
            $startInfo.Arguments = $argumentString
            $startInfo.UseShellExecute = $false
            $startInfo.CreateNoWindow = $true
            $startInfo.RedirectStandardOutput = $true
            $startInfo.RedirectStandardError = $true
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $startInfo
            if (-not $process.Start()) { throw 'Process did not start.' }
            $stdoutTask = $process.StandardOutput.ReadToEndAsync()
            $stderrTask = $process.StandardError.ReadToEndAsync()
            $process.WaitForExit()
            $code = $process.ExitCode
            $raw = $stdoutTask.GetAwaiter().GetResult() + "`r`n" + $stderrTask.GetAwaiter().GetResult()
        } else {
            $ErrorActionPreference = 'Continue'
            $global:LASTEXITCODE = $null
            $nativeOutput = @(& $Program @Arguments 2>&1)
            $code = $global:LASTEXITCODE
            $raw = ($nativeOutput | ForEach-Object { [string]$_ }) -join "`r`n"
        }
    } catch {
        $invocationError = $_ | Out-String -Width 4096
    } finally {
        $ErrorActionPreference = $previousPreference
        if ($null -ne $process) { $process.Dispose() }
    }
    $classification = 'OTHER'
    $classificationText = $raw + "`r`n" + $invocationError
    if ($classificationText -match '(?i)0x00000522') { $classification = 'INSUFFICIENT_PRIVILEGE' }
    elseif ($classificationText -match '(?i)0x00000005') { $classification = 'ACCESS_DENIED' }
    elseif ($classificationText -match '(?i)0x00000057') { $classification = 'INVALID_PARAMETER' }
    elseif ($null -ne $code -and $code -eq 0 -and -not $invocationError) { $classification = 'OK' }
    $exitText = if ($null -eq $code) { 'NOT_STARTED' } else { [string]$code }
    Write-Detail ("Time={0}`r`nProgram={1}`r`nArguments={2}`r`n{3}`r`nExit={4}`r`nClassification={5}`r`nInvocationError={6}`r`n" -f (Get-Date).ToString('o'), $Program, $argumentString, $raw, $exitText, $classification, $invocationError)
    if (([IO.Path]::GetFileName($Program) -eq 'auditpol.exe') -and $Arguments[0] -eq '/list') {
        Write-Output "AuditDiagnostic Exit=$exitText Classification=$classification"
    } else {
        Write-Output "Command=$Program $argumentString Exit=$exitText Classification=$classification"
    }
    return [pscustomobject]@{ Raw = $raw; Code = $code; ExitText = $exitText; Classification = $classification; OK = ($classification -eq 'OK') }
}

function Get-MaxSize($Result) {
    if (-not $Result.OK) { return $null }
    $matchesFound = [regex]::Matches($Result.Raw, '(?im)^\s*maxSize\s*:\s*([0-9]+)\s*$')
    if ($matchesFound.Count -ne 1) { return $null }
    $parsed = [uint64]0
    if ([uint64]::TryParse($matchesFound[0].Groups[1].Value, [ref]$parsed)) { return $parsed }
    return $null
}

function Get-CollapsedText([string]$Text) {
    if ($null -eq $Text) { return '' }
    return ([regex]::Replace($Text, '\s+', ' ')).Trim()
}

function Test-ExactLogonName([string]$Name) {
    return ((Get-CollapsedText $Name) -ieq 'Logon')
}

function Convert-OfficialAuditSetting([string]$Text) {
    $n = Get-CollapsedText $Text
    if ($n.Length -eq 0) { return $null }
    # Official English inclusion settings from auditpol get text and the documented CSV column "inclusion settings".
    # Kind is none, success, failure, or both. Localized or unknown tokens are rejected, not treated as success.
    if ($n -ieq 'Success and Failure') {
        return [pscustomobject]@{ Kind = 'Both'; Canonical = 'Success and Failure' }
    }
    if ($n -ieq 'No Auditing') {
        return [pscustomobject]@{ Kind = 'None'; Canonical = 'No Auditing' }
    }
    if ($n -ieq 'Failure') {
        return [pscustomobject]@{ Kind = 'Failure'; Canonical = 'Failure' }
    }
    if ($n -ieq 'Success') {
        return [pscustomobject]@{ Kind = 'Success'; Canonical = 'Success' }
    }
    return $null
}

function Get-RecordPropertyValue($Record, [string[]]$Names) {
    if ($null -eq $Record) { return $null }
    foreach ($want in $Names) {
        $wantNorm = Get-CollapsedText $want
        foreach ($p in $Record.PSObject.Properties) {
            if ((Get-CollapsedText ([string]$p.Name)) -ieq $wantNorm) {
                if ($null -eq $p.Value) { return '' }
                return [string]$p.Value
            }
        }
    }
    return $null
}

function Test-LooksLikeOfficialCsvHeader([string]$Header) {
    if ([string]::IsNullOrWhiteSpace($Header)) { return $false }
    if ($Header -notmatch ',') { return $false }
    $cells = @($Header.Split(',') | ForEach-Object { Get-CollapsedText $_ })
    $hasGuid = $false
    $hasNameOrSetting = $false
    foreach ($c in $cells) {
        if ($c -match '(?i)guid') { $hasGuid = $true }
        if ($c -match '(?i)subcategory') { $hasNameOrSetting = $true }
        if ($c -match '(?i)^inclusion settings?$') { $hasNameOrSetting = $true }
        if ($c -match '(?i)^setting$') { $hasNameOrSetting = $true }
    }
    return ($hasGuid -or $hasNameOrSetting)
}

function Get-CsvDataRows([string]$Raw) {
    $lines = @()
    foreach ($line in ($Raw -split '\r?\n')) {
        if ($line.Trim().Length -gt 0) { $lines += $line.TrimEnd() }
    }
    if ($lines.Count -lt 2) { return $null }
    if (-not (Test-LooksLikeOfficialCsvHeader $lines[0])) { return $null }
    try {
        $rows = @(ConvertFrom-Csv -InputObject $lines)
        if ($rows.Count -eq 0) { return $null }
        return $rows
    } catch {
        return $null
    }
}

function Get-GuidRegex([string]$Guid) {
    $guidBare = $Guid.Trim('{}')
    return [regex]::new('(?i)\{?\s*' + [regex]::Escape($guidBare) + '\s*\}?')
}

function Get-NameBesideGuid([string]$Line, [regex]$GuidRx) {
    $label = $GuidRx.Replace($Line, ' ')
    $label = [regex]::Replace($label, '[{}]', ' ')
    return Get-CollapsedText $label
}

function New-AuditParseResult([bool]$Parsed, $Kind, $Canonical, [string]$Reason) {
    return [pscustomobject]@{ Parsed = $Parsed; Kind = $Kind; Canonical = $Canonical; Reason = $Reason }
}

function Get-AuditPolicyValue($Result) {
    if ($null -eq $Result -or -not $Result.OK) { return New-AuditParseResult $false $null $null 'GET_NOT_OK' }
    if ($Result.Raw -match '(?i)用法:|usage:|0x00000057') { return New-AuditParseResult $false $null $null 'USAGE_OR_INVALID_PARAMETER' }

    $officialGuid = '0CCE9215-69AE-11D9-BED3-505054503030'
    $guidRx = Get-GuidRegex $officialGuid
    $found = @()

    $rows = Get-CsvDataRows $Result.Raw
    if ($null -ne $rows) {
        foreach ($row in $rows) {
            $name = Get-RecordPropertyValue $row @('subcategory', 'subcategory name')
            $guidVal = Get-RecordPropertyValue $row @('subcategory GUID', 'subcategoryGUID', 'GUID')
            $inclusionSetting = Get-RecordPropertyValue $row @('inclusion settings', 'inclusion setting', 'setting')
            $guidHit = $false
            if ($null -ne $guidVal -and $guidRx.IsMatch($guidVal)) { $guidHit = $true }
            $nameIsLogon = $false
            if ($null -ne $name -and (Test-ExactLogonName $name)) { $nameIsLogon = $true }
            $namePresent = ($null -ne $name -and (Get-CollapsedText $name).Length -gt 0)
            if ($guidHit -and $namePresent -and -not $nameIsLogon) {
                return New-AuditParseResult $false $null $null 'GET_NAME_MISMATCH'
            }
            if (-not ($guidHit -or $nameIsLogon)) { continue }
            $tok = Convert-OfficialAuditSetting $inclusionSetting
            if ($null -eq $tok) {
                return New-AuditParseResult $false $null $null 'SETTING_UNKNOWN_OR_MISSING'
            }
            $found += $tok
        }
    } else {
        $settingAlt = 'Success and Failure|No Auditing|Failure|Success'
        $rx = [regex]::new('(?i)^\s*(.+?)\s+(' + $settingAlt + ')\s*$')
        foreach ($line in ($Result.Raw -split '\r?\n')) {
            if ($line.Trim().Length -eq 0) { continue }
            $m = $rx.Match($line)
            if (-not $m.Success) { continue }
            $name = Get-CollapsedText $m.Groups[1].Value
            if (-not (Test-ExactLogonName $name)) { continue }
            $tok = Convert-OfficialAuditSetting $m.Groups[2].Value
            if ($null -eq $tok) { continue }
            $found += $tok
        }
    }

    if ($found.Count -eq 0) {
        return New-AuditParseResult $false $null $null 'AUDIT_VALUE_NOT_PARSED'
    }
    $kinds = @($found | ForEach-Object { $_.Kind } | Select-Object -Unique)
    if ($kinds.Count -ne 1) {
        return New-AuditParseResult $false $null $null 'AUDIT_VALUE_AMBIGUOUS'
    }
    $first = $found[0]
    return New-AuditParseResult $true $first.Kind $first.Canonical ('AUDIT_VALUE_' + $first.Kind.ToUpper())
}

function Get-AuditSummary($Result) {
    $parsed = Get-AuditPolicyValue $Result
    if ($parsed.Parsed) {
        return ($parsed.Canonical + ' [' + $parsed.Kind + ']')
    }
    # Do not echo titles, garbage, or unknown tokens as if they were a parsed policy value.
    return 'UNKNOWN'
}

function Test-AuditValueParsed($Result) {
    $parsed = Get-AuditPolicyValue $Result
    return [bool]$parsed.Parsed
}

function Test-OfficialLogonGuid($ListResult, [string]$Guid) {
    if (-not $ListResult.OK) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'LIST_NOT_OK' }
    }
    $guidRx = Get-GuidRegex $Guid
    $names = @()
    $usedCsv = $false
    $rows = Get-CsvDataRows $ListResult.Raw
    if ($null -ne $rows) {
        $guidColFound = $false
        foreach ($row in $rows) {
            $guidVal = Get-RecordPropertyValue $row @('subcategory GUID', 'subcategoryGUID', 'GUID')
            if ($null -eq $guidVal) { continue }
            $guidColFound = $true
            if (-not $guidRx.IsMatch($guidVal)) { continue }
            $name = Get-RecordPropertyValue $row @('subcategory', 'subcategory name')
            $names += (Get-CollapsedText $name)
            $usedCsv = $true
        }
        if (-not $guidColFound) {
            $usedCsv = $false
            $names = @()
        }
    }

    if (-not $usedCsv) {
        foreach ($line in ($ListResult.Raw -split '\r?\n')) {
            if (-not $guidRx.IsMatch($line)) { continue }
            $names += (Get-NameBesideGuid $line $guidRx)
        }
    }

    if ($names.Count -eq 0) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_ABSENT' }
    }

    $logonCount = @($names | Where-Object { Test-ExactLogonName $_ }).Count
    $emptyCount = @($names | Where-Object { $_.Length -eq 0 }).Count
    $otherCount = $names.Count - $logonCount - $emptyCount

    if ($logonCount -ge 1 -and $otherCount -eq 0 -and $emptyCount -eq 0) {
        return [pscustomobject]@{ Confirmed = $true; Reason = 'GUID_NAME_LOGON' }
    }
    if ($emptyCount -eq $names.Count) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_WITHOUT_NAME' }
    }
    if ($logonCount -ge 1) {
        return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_AMBIGUOUS' }
    }
    return [pscustomobject]@{ Confirmed = $false; Reason = 'GUID_LABEL_MISMATCH' }
}

try {
    New-Item -ItemType Directory -Path $localRoot -Force -ErrorAction Stop | Out-Null
    Set-Content -LiteralPath $localFile -Value "Start=$($started.ToString('o'))`r`n=== BEFORE ===" -Encoding UTF8 -ErrorAction Stop
    Write-Output "Start=$($started.ToString('o')) Local=$localFile"

    $isAdministrator = $false
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal = New-Object Security.Principal.WindowsPrincipal($identity)
            $isAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        } finally { $identity.Dispose() }
    } catch {
        if ($env:TB71_IS_ADMINISTRATOR -eq '1') { $isAdministrator = $true }
    }
    Write-Detail "IsAdministrator=$isAdministrator"
    Write-Output "IsAdministrator=$isAdministrator"
    $diagnosticItems = @(Invoke-Recorded $auditpolProg @('/list', '/subcategory:*', '/v'))
    $diagnostic = $diagnosticItems[-1]
    $diagnosticItems | Select-Object -SkipLast 1 | Write-Output

    # Capture and persist BOTH pre-change queries before any configuration.
    # Information stream redirection is not needed: the helper's short stdout
    # is separated from its result object here, preserving native exit codes.
    $beforeAuditItems = @(Invoke-Recorded $auditpolProg @('/get', $subcategory))
    $beforeAudit = $beforeAuditItems[-1]
    $beforeAuditItems | Select-Object -SkipLast 1 | Write-Output
    $beforeLogItems = @(Invoke-Recorded $wevtutilProg @('gl', 'Security'))
    $beforeLog = $beforeLogItems[-1]
    $beforeLogItems | Select-Object -SkipLast 1 | Write-Output
    $beforeSize = Get-MaxSize $beforeLog
    Write-Detail "BeforeMaxSize=$beforeSize"

    $guidCheck = Test-OfficialLogonGuid $diagnostic $officialLogonGuid
    $auditParsed = Test-AuditValueParsed $beforeAudit
    $sizeParsed = ($null -ne $beforeSize)
    $canWrite = [bool]($guidCheck.Confirmed -and $auditParsed -and $sizeParsed)
    Write-Detail ("GuidCheck Confirmed={0} Reason={1}`r`nAuditParsed={2}`r`nSizeParsed={3}`r`nCanWrite={4}" -f $guidCheck.Confirmed, $guidCheck.Reason, $auditParsed, $sizeParsed, $canWrite)
    Write-Output ("GuidCheck Confirmed={0} Reason={1} AuditParsed={2} SizeParsed={3} CanWrite={4}" -f $guidCheck.Confirmed, $guidCheck.Reason, $auditParsed, $sizeParsed, $canWrite)

    Write-Detail '=== CONFIGURATION ==='
    $auditSet = $null
    $sizeSet = $null
    $sizeAction = 'FAILED: current maxSize unavailable; no size change attempted'
    if (-not $canWrite) {
        $auditAction = 'FAILED: write gate blocked; no audit set and no log size change attempted'
        Write-Detail $auditAction
        Write-Output $auditAction
        $sizeAction = 'FAILED: write gate blocked; no size change attempted'
    } else {
        $auditItems = @(Invoke-Recorded $auditpolProg @('/set', $subcategory, '/failure:enable'))
        $auditSet = $auditItems[-1]
        $auditItems | Select-Object -SkipLast 1 | Write-Output
        if ($beforeSize -ge $minimum) {
            $sizeAction = '已满足、未改'
        } else {
            $sizeItems = @(Invoke-Recorded $wevtutilProg @('sl', 'Security', "/ms:$minimum"))
            $sizeSet = $sizeItems[-1]
            $sizeItems | Select-Object -SkipLast 1 | Write-Output
            $sizeAction = "Requested=$minimum Exit=$($sizeSet.ExitText)"
        }
    }
    Write-Detail "SecuritySizeAction=$sizeAction"

    Write-Detail '=== AFTER ==='
    $afterAuditItems = @(Invoke-Recorded $auditpolProg @('/get', $subcategory))
    $afterAudit = $afterAuditItems[-1]
    $afterAuditItems | Select-Object -SkipLast 1 | Write-Output
    $afterLogItems = @(Invoke-Recorded $wevtutilProg @('gl', 'Security'))
    $afterLog = $afterLogItems[-1]
    $afterLogItems | Select-Object -SkipLast 1 | Write-Output
    $afterSize = Get-MaxSize $afterLog

    $auditOK = ($null -ne $auditSet -and $auditSet.OK -and $afterAudit.OK)
    $sizeOK = ($null -ne $beforeSize -and $null -ne $afterSize -and $afterSize -ge $minimum -and $afterSize -ge $beforeSize)
    if ($null -ne $sizeSet -and -not $sizeSet.OK) { $sizeOK = $false }
    $auditStatus = if ($auditOK) { 'SUCCESS (set accepted; raw policy recorded)' } else { 'FAILED (see command output/exit codes)' }
    $sizeStatus = if ($sizeOK) { 'SUCCESS' } else { 'FAILED (read/set/verification; see raw output)' }
    Write-Detail "Audit=$auditStatus`r`nSecuritySize=$sizeStatus`r`nBeforeMaxSize=$beforeSize AfterMaxSize=$afterSize`r`nSecuritySizeAction=$sizeAction"
    Write-Detail "EndLocal=$((Get-Date).ToString('o'))`r`nShareCopy=PENDING; final ShareCopy and EXIT appear in runner stdout."
    Write-Output "Audit=$auditStatus Before=[$(Get-AuditSummary $beforeAudit)] After=[$(Get-AuditSummary $afterAudit)]"
    Write-Output "SecuritySize=$sizeStatus Before=$beforeSize After=$afterSize Action=$sizeAction"

    $copied = $false
    $attempts = 0
    for ($attempt = 1; $attempt -le 6; $attempt++) {
        $attempts = $attempt
        try {
            New-Item -ItemType Directory -Path $share -Force -ErrorAction Stop | Out-Null
            Copy-Item -LiteralPath $localFile -Destination $share -Force -ErrorAction Stop
            $copied = $true
            break
        } catch {
            if ($attempt -lt 6) { [System.Threading.Thread]::Sleep(5000) }
        }
    }
    if (-not $copied) {
        Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile LocalComplete=True ShareCopy=False Attempts=$attempts EXIT=2"
        exit 2
    }
    Write-Output "ShareCopy=True Attempts=$attempts"
    # Failed configuration cannot claim the all-success exit code. Escalate
    # the fully recorded failure to the script-level exception handler.
    if (-not $auditOK -or -not $sizeOK) { throw 'Configuration failed; complete command results are in 71-config.txt.' }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile EXIT=0"
    exit 0
} catch {
    # Never change the local snapshot after a successful transfer.
    if (-not $copied) {
        try { Write-Detail ("ScriptException=" + ($_ | Out-String -Width 4096)) } catch { }
    }
    Write-Output "End=$((Get-Date).ToString('o')) Local=$localFile ScriptException=True EXIT=1"
    exit 1
}
