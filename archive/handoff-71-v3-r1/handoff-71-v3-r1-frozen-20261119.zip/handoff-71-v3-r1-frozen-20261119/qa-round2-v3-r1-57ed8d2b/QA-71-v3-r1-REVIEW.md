# TunnelBrowser 71 v3-r1 独立QA第二轮

结论：fail；上机blocked，交PM裁决，不自动安排第三轮实现。

候选sha256：57ed8d2beb604b0c061e0346303ba252947bea3b94ead89ff3a98372945d55cc。
环境：共享Linux，PowerShell 7.5.13，命令运行原脚本，auditpol/wevtutil为离线桩；未接触Windows。
原QA套件20/20（run.log、run.exit）；新增边界4通过/2失败（boundaries.log、boundaries.json、boundaries.exit）。作者41/41不是本报告证据。

## 阻塞缺陷
1. 高：脚本158–160、256行GUID匹配无首尾约束；list CSV的GUID为官方完整值后附FFFF，仍确认并触发/set及sl各1次，exit0。预期零写入。
2. 高：脚本184–200行get CSV在名称Logon而GUID为Logoff时，因OR条件接受为有效原值；仍触发/set及sl各1次，exit0。预期GUID与名称冲突时零写入。

## 通过边界
原值冲突、list同GUID不同名称、未知本地化、CSV缺失setting均应零写，实际见逐项JSON。

## 复现命令
`PATH=/home/box/opt/powershell/7:$PATH /home/box/opt/powershell/7/pwsh -NoProfile -File /workspace/tunnelbrowser/qa-71-v3-r1-57ed8d2b/Run-Boundaries.ps1 -ScriptUnderTest /workspace/tunnelbrowser/tbshare/tb4/jobs/71-tb4-config.v3-r1.ps1 -EvidenceFile /workspace/tunnelbrowser/qa-71-v3-r1-57ed8d2b/boundaries`

原v3首次失败及r1原20例证据保留；本次未改实现/旧QA，新增反例仅在QA目录。
Windows5.1、目标GUID实际映射、实际原值、恢复通道、配置写入及Release均unrun/未授权，不视为通过。无生产影响已被证明，只有离线模拟缺陷。
质量建议no-go；用户批准未获得。
