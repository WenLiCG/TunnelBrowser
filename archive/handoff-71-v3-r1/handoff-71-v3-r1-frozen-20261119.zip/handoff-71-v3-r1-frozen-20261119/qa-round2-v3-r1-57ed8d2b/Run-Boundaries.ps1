# Public test entry for 71 v3 write-gate behavior.
# Invokes the real script under test via pwsh -File. Assertions count stub journal
# entries for auditpol /set and wevtutil sl only. Does not copy script branch logic.
param(
    [Parameter(Mandatory = $true)]
    [string]$ScriptUnderTest,
    [string]$EvidenceFile = ''
)

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$stubPy = '/workspace/tunnelbrowser/tbshare/tb4/jobs/71-v3-delivery/tests/stubs/tool_stub.py'
$python = (Get-Command python3).Source
$officialGuid = '0CCE9215-69AE-11D9-BED3-505054503030'
$scriptGuidTypo = '0CCE9215-69AE-11D9-BED3-505400000000'

$glSmall = @"
name: Security
enabled: true
type: Admin
owningPublisher: 
isolation: Custom
channelAccess: O:BAG:SYD:(A;;0xf0005;;;SY)
logging:
  logFileName: %SystemRoot%\System32\Winevt\Logs\Security.evtx
  retention: false
  autoBackup: false
  maxSize: 20971520
publishing:
  fileMax: 1
"@

$glLarge = $glSmall -replace 'maxSize: 20971520', 'maxSize: 268435456'
$glNoMax = @"
name: Security
enabled: true
type: Admin
logging:
  retention: false
  autoBackup: false
publishing:
  fileMax: 1
"@

$getFailure = @"
System audit policy
Category/Subcategory                      Setting
Logon/Logoff
  Logon                                   Failure
"@

$getNoAuditing = @"
System audit policy
Category/Subcategory                      Setting
Logon/Logoff
  Logon                                   No Auditing
"@

$usage = @"
用法: AuditPol command [<sub-command><options>]


发生错误 0x00000057:
"@

$priv = @"
发生错误 0x00000522:
无法完成操作。缺少所需特权。
"@

function New-ListText([string]$Guid, [string]$Label) {
    return @"
Category/Subcategory                      GUID
Logon/Logoff
  $Label                               {$Guid}
  Logoff                               {0CCE9216-69AE-11D9-BED3-505054503030}
"@
}

$passed = 0
$failed = 0
$results = @()

function Write-Result([string]$Name, [bool]$Ok, [string]$Detail) {
    $script:results += [pscustomobject]@{ Name = $Name; OK = $Ok; Detail = $Detail }
    if ($Ok) {
        $script:passed++
        Write-Output "PASS $Name"
    } else {
        $script:failed++
        Write-Output "FAIL $Name :: $Detail"
    }
    if ($Detail) { Write-Output "  $Detail" }
}

function Invoke-Case {
    param(
        [string]$Name,
        [hashtable]$Scenario,
        [scriptblock]$Assert,
        [switch]$OmitAuditpol,
        [switch]$OmitWevtutil,
        [switch]$BreakShare
    )
    $root = Join-Path ([IO.Path]::GetTempPath()) ("tb71v3-" + [guid]::NewGuid().ToString('n'))
    $local = Join-Path $root 'local'
    $share = Join-Path $root 'share'
    $bin = Join-Path $root 'bin'
    $journal = Join-Path $root 'journal.jsonl'
    $scenarioFile = Join-Path $root 'scenario.json'
    New-Item -ItemType Directory -Force -Path $local, $share, $bin | Out-Null
    Set-Content -LiteralPath $scenarioFile -Value ($Scenario | ConvertTo-Json -Depth 8) -Encoding UTF8
    if (-not $OmitAuditpol) {
        $auditpol = Join-Path $bin 'auditpol.exe'
        New-Item -ItemType SymbolicLink -Path $auditpol -Target $python | Out-Null
        # python3 shebang won't run as auditpol.exe; use wrapper
        Remove-Item -LiteralPath $auditpol -Force
        $wrapper = @"
#!/usr/bin/env bash
exec "$python" "$stubPy" "\$@"
"@
        # The above escapes wrong; write carefully below
    }
    $wrapperTemplate = @'
#!/usr/bin/env bash
export TB71_STUB_PROGRAM=PROGRAM_PLACEHOLDER
export PYTHONUNBUFFERED=1
exec 'PYTHON_PLACEHOLDER' 'STUB_PLACEHOLDER' "$@"
'@
    $wrapperTemplate = $wrapperTemplate.Replace('PYTHON_PLACEHOLDER', $python).Replace('STUB_PLACEHOLDER', $stubPy)
    function Write-Wrapper([string]$Path, [string]$Program) {
        $text = $wrapperTemplate.Replace('PROGRAM_PLACEHOLDER', $Program)
        Set-Content -LiteralPath $Path -Value $text -Encoding utf8NoBOM
        & chmod +x $Path
    }
    if (-not $OmitAuditpol) { Write-Wrapper (Join-Path $bin 'auditpol.exe') 'auditpol.exe' }
    if (-not $OmitWevtutil) { Write-Wrapper (Join-Path $bin 'wevtutil.exe') 'wevtutil.exe' }
    if ($BreakShare) {
        Remove-Item -LiteralPath $share -Recurse -Force -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $share -Value 'not-a-directory' -Encoding utf8NoBOM
    }

    $env:TB71_LOCAL_ROOT = $local
    $env:TB71_SHARE = $(if ($BreakShare) { Join-Path $share 'raw' } else { $share })
    $env:TB71_JOURNAL = $journal
    $env:TB71_SCENARIO = $scenarioFile
    $env:TB71_IS_ADMINISTRATOR = '1'
    $env:TB71_AUDITPOL = $(if ($OmitAuditpol) { 'auditpol.exe' } else { Join-Path $bin 'auditpol.exe' })
    $env:TB71_WEVTUTIL = $(if ($OmitWevtutil) { 'wevtutil.exe' } else { Join-Path $bin 'wevtutil.exe' })
    $stdoutFile = Join-Path $root 'stdout.txt'
    $stderrFile = Join-Path $root 'stderr.txt'
    $pwsh = (Get-Command pwsh).Source
    $proc = Start-Process -FilePath $pwsh -ArgumentList @('-NoProfile', '-File', $ScriptUnderTest) -Wait -PassThru -NoNewWindow -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile
    $exitCode = $proc.ExitCode
    $journalLines = @()
    if (Test-Path -LiteralPath $journal) {
        $journalLines = @(Get-Content -LiteralPath $journal -Encoding UTF8 | Where-Object { $_.Trim().Length -gt 0 } | ForEach-Object { $_ | ConvertFrom-Json })
    }
    function Test-ArgMatch($entry, [string]$Token) {
        $list = @($entry.args | ForEach-Object { [string]$_ })
        if ($list -contains $Token) { return $true }
        if ($list.Count -eq 1 -and ($list[0] -split '\s+') -contains $Token) { return $true }
        return $false
    }
    $writeSet = @($journalLines | Where-Object { (Test-ArgMatch $_ '/set') })
    $writeSl = @($journalLines | Where-Object { (Test-ArgMatch $_ 'sl') })
    $info = [pscustomobject]@{
        Name = $Name
        Root = $root
        ExitCode = $exitCode
        Journal = $journalLines
        WriteSet = $writeSet
        WriteSl = $writeSl
        WriteCount = ($writeSet.Count + $writeSl.Count)
        StdOut = (Get-Content -LiteralPath $stdoutFile -Encoding UTF8 -ErrorAction SilentlyContinue) -join "`n"
        StdErr = (Get-Content -LiteralPath $stderrFile -Encoding UTF8 -ErrorAction SilentlyContinue) -join "`n"
        LocalFile = Join-Path $local '71-config.txt'
    }
    try {
        & $Assert $info
    } catch {
        Write-Result $Name $false ($_ | Out-String)
    }
}

function Expect-ZeroWrites($info, [string]$Name) {
    if ($info.WriteCount -eq 0) {
        Write-Result $Name $true ("writes=0 exit=$($info.ExitCode) set=$($info.WriteSet.Count) sl=$($info.WriteSl.Count)")
    } else {
        $detail = "writes=$($info.WriteCount) set=$($info.WriteSet.Count) sl=$($info.WriteSl.Count) exit=$($info.ExitCode) journal=$($info.Journal | ConvertTo-Json -Compress)"
        Write-Result $Name $false $detail
    }
}

# --- default happy pieces ---
$okListOfficial = New-ListText $officialGuid 'Logon'
$okListTypoOnly = New-ListText $scriptGuidTypo 'Logon'
$mismatchLabel = New-ListText $officialGuid 'Logoff'

$baseOk = @{
    list = @{ exit = 0; stdout = $okListOfficial; stderr = '' }
    get  = @{ exit = 0; stdout = $getNoAuditing; stderr = '' }
    set  = @{ exit = 0; stdout = 'The command was successfully executed.'; stderr = '' }
    gl   = @{ exit = 0; stdout = $glSmall; stderr = '' }
    sl   = @{ exit = 0; stdout = ''; stderr = '' }
}


$cases = @(
 @{Name='B01_list_guid_suffix'; List="subcategory,subcategory GUID`nLogon,${officialGuid}FFFF"},
 @{Name='B02_get_wrong_guid_with_logon'; Get="subcategory,subcategory GUID,inclusion settings`nLogon,0CCE9216-69AE-11D9-BED3-505054503030,No Auditing"},
 @{Name='B03_get_conflicting_values'; Get="Logon No Auditing`nLogon Success"},
 @{Name='B04_list_conflicting_names'; List="Logon {$officialGuid}`nLogoff {$officialGuid}"},
 @{Name='B05_localized_unknown'; Get='登录 无审核'},
 @{Name='B06_get_csv_missing_setting'; Get="subcategory,subcategory GUID`nLogon,$officialGuid"}
)
foreach($c in $cases) {
 $scenario=@{}; foreach($key in $baseOk.Keys){$scenario[$key]=$baseOk[$key]}
 if($c.ContainsKey('List')){$scenario['list']=@{exit=0;stdout=$c.List;stderr=''}}
 if($c.ContainsKey('Get')){$scenario['get']=@{exit=0;stdout=$c.Get;stderr=''}}
 $caseName=$c.Name
 Invoke-Case $caseName $scenario {param($i) Expect-ZeroWrites $i $i.Name}
}
$results | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($EvidenceFile+'.json') -Encoding UTF8
Write-Output "SUMMARY passed=$passed failed=$failed"
if($failed -gt 0){exit 1}
exit 0
